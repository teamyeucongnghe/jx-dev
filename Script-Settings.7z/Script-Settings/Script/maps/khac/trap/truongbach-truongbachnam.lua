
function main(sel)

	NewWorld(321,967,2297)		--	
	SetFightState(1)		--
    AddWayPoint(198)

end;
