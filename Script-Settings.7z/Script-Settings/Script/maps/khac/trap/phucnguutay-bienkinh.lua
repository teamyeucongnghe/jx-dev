
function main(sel)
 	NewWorld(37,1132,3232)		--	
	SetFightState(1)		--

end;
