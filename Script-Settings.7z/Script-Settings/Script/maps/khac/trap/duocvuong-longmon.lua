
function main(sel)
  	
	NewWorld(121,2287,4409)		--	
	SetFightState(1)		--

end;
