
function main(sel)

	NewWorld(321, 1567,3126)		--	
	SetFightState(1)		--
    AddWayPoint(199)

end;
