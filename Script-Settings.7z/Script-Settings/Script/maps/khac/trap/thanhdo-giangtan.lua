
function main(sel)

	NewWorld(20, 3404,6028)		--	
	SetFightState(1)		--
end;
