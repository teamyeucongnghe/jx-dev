
function main(sel)

	if(NewWorld(54,1618,2969) == 1) then		--	
	SetFightState(0)		--
	end
end;
