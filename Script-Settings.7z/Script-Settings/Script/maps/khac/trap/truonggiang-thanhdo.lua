
function main(sel)

	NewWorld(11,2724,5320)		--	
	SetFightState(1)		--
end;
