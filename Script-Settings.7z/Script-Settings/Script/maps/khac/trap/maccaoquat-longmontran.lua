
function main(sel)
  	NewWorld(121,1724,4273)		--	
	SetFightState(1)		--

end;
