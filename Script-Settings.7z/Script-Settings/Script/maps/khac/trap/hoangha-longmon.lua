
function main(sel)

	NewWorld(121,1714,4394)		--	
	SetFightState(1)		--

end;
