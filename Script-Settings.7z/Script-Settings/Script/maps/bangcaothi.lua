-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

-- Bang Cao Thi
function main(sel)
	Talk(1,"","<< Khu v�c th�nh "..GetWorldName().." >>");
end