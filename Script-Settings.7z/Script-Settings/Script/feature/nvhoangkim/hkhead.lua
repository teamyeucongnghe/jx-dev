-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
END_TALK = "K�t th�c ��i tho�i"
NOTEHEAD = "Nhi�m v� Ho�ng Kim: "
function taykynang()
	ResetMagicPoint();
end;