-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

function OnDeath(nDesNpcIndex)
	local campme = GetCurCamp();
	local nDesPlayerIdx = NpcIdx2PIdx(nDesNpcIndex);
	PlayerIndex = nDesPlayerIdx;
	if(GetCurCamp() == campme) then
	return end
	local nDesPlayerData	= PIdx2MSDIdx(1,nDesPlayerIdx);
	local nDesOnline = GetPMParam(1,nDesPlayerData,0);
	if(nDesPlayerData > 0 and nDesOnline == 1) then	--co ton tai. dang online
		local nTichluy = GetPMParam(1,nDesPlayerData,1)+1;
		SetPMParam(1,nDesPlayerData,1,nTichluy)	--giet duoc
		Msg2Player("B�n h� s�t "..nTichluy.." k� ��ch")
	end
end;

