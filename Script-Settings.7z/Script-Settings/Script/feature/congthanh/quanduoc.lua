-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function main(sel)
dofile("script/feature/congthanh/quanduoc.lua")
ActiveHT()
end

function ActiveHT()

end;

function yes()
Sale(12,0);
end;


function no()
end;
