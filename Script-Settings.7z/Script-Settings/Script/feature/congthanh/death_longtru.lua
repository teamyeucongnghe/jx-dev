-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

--Nguoi choi giet quai cuoi cung
function LastDamage(NpcIndex)
end
NPCLIFE = 10000000
--khi hoi sinh
function Revive(NpcIndex)
	local Series = GetNpcSer(NpcIndex);--
	local nSTVL, nDoc, nBang, nHoa, nLoi = 0,0,0,0,0;

	    --SetCurCamp(chinhphai)
        SetNpcSer(NpcIndex, "555")--Ngò Hµnh
		SetNpcLife(NpcIndex, NPCLIFE);--M¸u.
		SetNpcReplenish(NpcIndex,1);--phuc hoi sinh luc	
        SetNpcDmgRet(NpcIndex, 10)	--Ph¶n damage %
		SetNpcDmgEx(NpcIndex,nSTVL, nDoc, nBang, nHoa, nLoi ,0);--
		SetNpcDmgEx(NpcIndex,nSTVL, nDoc, nBang, nHoa, nLoi ,1);--
		SetNpcResist(NpcIndex, 75, 75, 75, 75, 75);--khang' cac loai
end
--Khi long tru chet
function DeathSelf(NpcIndex)

end