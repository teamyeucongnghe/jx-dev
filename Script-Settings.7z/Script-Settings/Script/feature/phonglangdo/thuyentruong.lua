-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
-- npc thuyenphu phonglang
function main(NpcIndex)
		Talk(1,"",10135)
end;
