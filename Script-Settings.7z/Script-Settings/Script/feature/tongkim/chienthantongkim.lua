-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

Include("\\script\\library\\worldlibrary.lua");

function main(NpcIndex)
Say("Xin ch�o ��i hi�p "..GetName().." Chi�n tr��ng ��m m�u, ��i hi�p h�y c�n tr�ng!",10,	
"Mua ��o C� T�ng Kim/muadaocu",
"Nh�n M�u Mi�n Ph�./maumienphi",
"K�t th�c ��i tho�i./no")
end

function muadaocu()
	Sale(95,3)
end;

function maumienphi()
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0); 
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0); 
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0); 
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0);
AddItem(0,1,3,0,0,10,0,0);
end;

function no()

end
