-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function OnTimer()
	StopTimer();
end;

function OnMissionTimer(nIndex)
	StopMissionTimer(nIndex,7);
end;