-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function OnTimer()
	StopTimer();
	Msg2Player("B�n �� gia nh�p <color=green>"..GetFaction());
end;

function OnMissionTimer(nIndex)
	StopMissionTimer(nIndex,5);
end;