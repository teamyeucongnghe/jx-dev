-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

function main(NpcIndex)
dofile("script\\vinagame.lua")
vinagame()
end

function  vinagame()
Talk(1,"no","")
end

function no()
end;
