-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Include("\\script\\library\\worldlibrary.lua");

function main()
Talk(1,"",11274)
end
