-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\testgame.lua");
Include("\\script\\header\\nhanhotro.lua");
Include("\\script\\item\\\\tools\\tool0059.lua");


function phiphong()
for i=3466,3488 do
AddItemGold(i)
end
end

function ngocan()
for i=3206,3235 do
AddItemGold(i)
end
end

function trangsuc()
for i=3492,3507 do
AddItemGold(i)
end
end

function matnahk()
for i=4609,4631 do
AddItemGold(i)
end
end 

function no()
end
