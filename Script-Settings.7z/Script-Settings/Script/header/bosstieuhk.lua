-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
BOSSTIEU_ARRAY={
{"Di�u Nh� ",513,"222",{1,6}},
{"Li�u Thanh Thanh",523,"111",{2,5}},
{"Tr��ng T�ng Ch�nh",511,"444",{3,4}}
};

POSITION_ARRAY={
{1,1765*32,3128*32},
{1,1800*32,3071*32},
{11,2909*32,4926*32},
{11,2961*32,4814*32},
{37,1958*32,2785*32},
{37,2014*32,2844*32},
{80,1504*32,3371*32},
{80,1470*32,3310*32},
{78,1319*32,3136*32},
{78,1653*32,3540*32},
{176,1745*32,3388*32},
{176,1767*32,3378*32},
{162,1404*32,3464*32},
{162,1775*32,3395*32},
{53,1625*32,3411*32},
{53,1536*32,3425*32},
{1,1765*32,3128*32},
{1,1800*32,3071*32},
{80,1470*32,3310*32},
{78,1319*32,3136*32},
{78,1653*32,3540*32},
{176,1745*32,3388*32},
{176,1767*32,3378*32},
{162,1404*32,3464*32},
{162,1775*32,3395*32},
{53,1625*32,3411*32},
{53,1536*32,3425*32},
{1,1765*32,3128*32},
{1,1800*32,3071*32},
{11,2909*32,4926*32},
{11,2961*32,4814*32},
{37,1958*32,2785*32},
{37,2014*32,2844*32}
};

COMMON_INFO = "<color=green>%s <color>xu�t hi�n t�i <color=green>%s <color>t�a �� <color=yellow>(%d,%d)"

function releasebosstieu()
	local nNpcIndex = 0;
	local nPos = 1;
	for i=1,getn(BOSSTIEU_ARRAY) do
		nPos = RANDOM(1,2);
		nPos = BOSSTIEU_ARRAY[i][4][nPos];
		nNpcIndex = AddNpcNew(BOSSTIEU_ARRAY[i][2],100,POSITION_ARRAY[nPos][1],
		POSITION_ARRAY[nPos][2],POSITION_ARRAY[nPos][3],"\\script\\global\\lastdamage\\death_tieuhk.lua",
	    5,nil,1,BOSSTIEU_ARRAY[i][3],5000000,10000000,10000,10000,nil,nil,nil,nil,nil,80,2,"\\script\\global\\droprate\\drop_tieuhk.lua");--
		if(nNpcIndex > 0) then
			SetNpcLifeTime(nNpcIndex, 48600);
			Msg2SubWorld(format(COMMON_INFO,BOSSTIEU_ARRAY[i][1],
			GetSubWorldName(POSITION_ARRAY[nPos][1]),
			floor(POSITION_ARRAY[nPos][2]/256),
			floor(POSITION_ARRAY[nPos][3]/512)));
		end
	end
end