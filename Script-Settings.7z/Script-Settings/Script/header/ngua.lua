-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\testgame.lua");
Include("\\script\\header\\nhanhotro.lua");
Include("\\script\\item\\\\tools\\tool0059.lua");


function thu1()
	nIndex = ItemSetAdd(0,0,10,5,10,0,0); -- Chieu Da Ngoc Su Tu
	SetItemDate(nIndex,43200)
	AddItemID(nIndex)
end

function thu2()
	nIndex = ItemSetAdd(0,0,10,5,6,0,0); -- O Van Dap Tuyet
	SetItemDate(nIndex,43200)
	AddItemID(nIndex)
end

function thu3()
	nIndex = ItemSetAdd(0,0,10,6,10,0,0); -- O Van Dap Tuyet
	SetItemDate(nIndex,43200)
	AddItemID(nIndex)
end

function thu4()
	nIndex = ItemSetAdd(0,0,10,7,10,0,0); -- Phien Vu
	SetItemDate(nIndex,43200)
	AddItemID(nIndex)
end

function thu5()
	nIndex = ItemSetAdd(0,0,10,8,10,0,0); -- Phi Van
	SetItemDate(nIndex,43200)
	AddItemID(nIndex)
end

function thu6()
	nIndex = ItemSetAdd(0,0,10,9,10,0,0); -- Xich Long Cau
	SetItemDate(nIndex,43200)
	AddItemID(nIndex)
end

function thu7()
	nIndex = ItemSetAdd(0,0,10,10,10,0,0); -- Tuyet Dia
	SetItemDate(nIndex,43200)
	AddItemID(nIndex)
end

function thu8()
	nIndex = ItemSetAdd(0,0,10,11,10,0,0); -- Du Huy
	SetItemDate(nIndex,43200)
	AddItemID(nIndex)
end

function thu9()
	nIndex = ItemSetAdd(0,0,10,13,10,0,0); -- Sieu Quang
	SetItemDate(nIndex,43200)
	AddItemID(nIndex)
end

function thu10()
	nIndex = ItemSetAdd(0,0,10,18,10,0,0); -- Han Huyet Long Cau
	SetItemDate(nIndex,43200)
	AddItemID(nIndex)
end

function thuhk1()
	AddItem(2,0,5092,0,0,0,5,0)
end

function thuhk2()
	AddItem(2,0,5093,0,0,0,5,0)
end

function thuhk3()
	AddItem(2,0,5094,0,0,0,5,0)
end

function thuhk4()
	AddItem(2,0,5095,0,0,0,5,0)
end

function thuhk5()
	AddItem(2,0,5096,0,0,0,5,0)
end
function thuhk6()
	nIndex = ItemSetAdd(0,0,10,34,1,0,0); -- Ky L�n
	SetItemDate(nIndex,43200)
	AddItemID(nIndex)
end

