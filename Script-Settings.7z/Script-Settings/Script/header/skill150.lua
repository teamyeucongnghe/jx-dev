-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
SKILL150_ARRAY={
-------------150 Thieu Lam-----------------------
	1055, --- Dai luc kim cang chuong
	1056, --- Vi da hien xu
	1057, --- tam gioi quy thien
	-------------150 Thien Vuong-----------------------
	1058, --- Hao hung tram
	1059, --- Tung hoanh bat hoang
	1060, --- Ba vuong Tam Kim
	-------------150 Nga Mi-----------------------
	1061, --- Kiem Hoa Van Tinh
	1062, --- Bang Vu Lac Tinh
	---------------150 Thuy Yen-----------------------
	1063, --- Bang Tuoc Hoat Ky
	1065, --- Thuy Anh Man Tu
	---------------150 Duong Mon-----------------------
	1069, --- Vo Anh xuyen
	1070, --- Thiet Lien Tu Sat
	1071, --- Can Khon Nhat Trich
	---------------150 Ngu doc-----------------------
	1066, --- Hinh Tieu cot lap
	1067, --- U Hon phe Anh
	---------------150 Cai Bang-----------------------
	1073, --- Thoi thua Luc Long
	1074, --- Bong Huynh Luoc dia
	---------------150 Thien Nhan-----------------------
	1075, --- Giang Hai no Lan
	1076, --- Tat Hoa Lieu Nguyen
	---------------150 Vo Dang-----------------------
	1078, --- Tao hoa Thai thanh
	1079, --- Kiem Thuy tinh Ha
	---------------150 Con Lon-----------------------
	1080, --- Cuu Thien Cuong phong
	1081 --- Thien Loi chan Nhac
};
