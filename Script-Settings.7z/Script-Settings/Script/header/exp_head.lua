-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--ty le x kinh nghiem
EXP_RATE	= 1 --x 1