-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");

ENAM = 2024
ETHANG = 7
ENGAY = 21
--------------------Active Event --------------------
EVENT_ACTIVE 	= 1
------------------------------------------------------

IDQuestKey1		= 165	-- danh quai
IDQuestKey2		= 165	-- hoat dong

-----------------TY LE VAT PHAM ROT RA------------------

RateMap7x 		= 100	
RateMap8x 		= 100	
RateMap9x 		= 100	

------------------------------------------------------
SoLuongTK		= 5	    -- tong kim
SoLuongVA		= 10    -- vuot ai
SoLuongPLD		= 5	    -- phong lang do
SoLuongST		= 2		-- sat thu
SoLuongDT		= 2		-- da tau
SoLuongNCD		= 5		-- da tau
------------------------------------------------------
SoLuongTKTSN		= 3	-- tong kim
SoLuongVATSN		= 4	-- vuot ai
SoLuongPLDTSN		= 2	-- phong lang do
SoLuongSTTSN		= 2		-- sat thu
SoLuongDTTSN		= 2		-- da tau

-----------MAP TRIEN KHAI EVENT----------

function DropEventMap7x(NpcIndex) --Map 7X
	if (EVENT_ACTIVE == 1) then
		if (RANDOM(RateMap7x) == 20) then
			local nItemIdx = ItemSetAdd(0,5,IDQuestKey1,0,0,5,1,0)
			SetItemDate(nItemIdx,ENAM,ETHANG,ENGAY,0,0);
			DropNpcItemID(NpcIndex, nItemIdx);
		end
	end
end

function DropEventMap8x(NpcIndex) --Map 8X
	if (EVENT_ACTIVE == 1) then
		if (RANDOM(RateMap8x) == 20) then
			local nItemIdx = ItemSetAdd(0,5,IDQuestKey1,0,0,5,1,0)
			SetItemDate(nItemIdx,ENAM,ETHANG,ENGAY,0,0);
			DropNpcItemID(NpcIndex, nItemIdx);
		end
	end
end

function DropEventMap9x(NpcIndex) --Map 9X
	if (EVENT_ACTIVE == 1) then
		if (RANDOM(RateMap9x) == 20) then
			local nItemIdx = ItemSetAdd(0,5,IDQuestKey1,0,0,5,1,0)
			SetItemDate(nItemIdx,ENAM,ETHANG,ENGAY,0,0);
			DropNpcItemID(NpcIndex, nItemIdx);
		end
	end
end

-----------EVENT HOAT DONG----------

function DropEventTK() --Tong Kim
	if EVENT_ACTIVE == 1 then
		local nItemIdx = ItemSetAdd(0,5,IDQuestKey2,0,0,5,SoLuongTKTSN,0)
		SetItemDate(nItemIdx,ENAM,ETHANG,ENGAY,0,0);
		AddItemID(nItemIdx);
	end
end

function DropEventVA() --Vuot Ai
	if EVENT_ACTIVE == 1 then
		local nItemIdx = ItemSetAdd(0,5,IDQuestKey2,0,0,5,SoLuongVATSN,0)
		SetItemDate(nItemIdx,ENAM,ETHANG,ENGAY,0,0);
		AddItemID(nItemIdx);
	end
end

function DropEventST() --Sat Thu
	if EVENT_ACTIVE == 1 then
		local nItemIdx = ItemSetAdd(0,5,IDQuestKey2,0,0,5,SoLuongSTTSN,0)
		SetItemDate(nItemIdx,ENAM,ETHANG,ENGAY,0,0);
		AddItemID(nItemIdx);
	end
end

function DropEventDT() --Da Tau
	if EVENT_ACTIVE == 1 then
		local nItemIdx = ItemSetAdd(0,5,IDQuestKey2,0,0,5,SoLuongDTTSN,0)
		SetItemDate(nItemIdx,ENAM,ETHANG,ENGAY,0,0);
		AddItemID(nItemIdx);
	end
end

function DropEventPLD() --Phong Lang Do
	if EVENT_ACTIVE == 1 then
		local nItemIdx = ItemSetAdd(0,5,IDQuestKey2,0,0,5,SoLuongTTTSN,0)
		SetItemDate(nItemIdx,ENAM,ETHANG,ENGAY,0,0);
		AddItemID(nItemIdx);
	end
end

function DropEventNCD() --Da Tau
	if EVENT_ACTIVE == 1 then
		local nItemIdx = ItemSetAdd(0,5,IDQuestKey2,0,0,5,SoLuongNCDSN,0)
		SetItemDate(nItemIdx,ENAM,ETHANG,ENGAY,0,0);
		AddItemID(nItemIdx);
	end
end
------------------------------------------------------
