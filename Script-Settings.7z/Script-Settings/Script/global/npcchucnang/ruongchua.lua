-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

function main(NpcIndex)
	OpenBox();
	local nRevivalid = GetNpcValue(NpcIndex)
	if(nRevivalid ~= nil and nRevivalid > 0) then
	SetRevPos(nRevivalid)
	end
end