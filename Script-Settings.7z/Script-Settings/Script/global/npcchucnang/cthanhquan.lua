-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\time.lua");
Include("\\script\\header\\tongkim.lua");
Include("\\script\\library\\worldlibrary.lua")

function main(NpcIndex)
dofile("script\\global\\npcchucnang\\cthanhquan.lua")
cthanhquan()
end

function cthanhquan()
	Say("Tr�n chi�n �ang di�n ra quy�t li�t. T��ng qu�n h�y mau d�n qu�n ra tr�n d�p lo�n !",4,
        "T�m Hi�u C�ng Th�nh Chi�n./timhieu",
        "K�t th�c ��i tho�i./no")
end

function timhieu()
	Talk(5,"",12252,12259,12260,12261,12262)
end

function no()

end
