-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function main(NpcIndex)
dofile("script\\global\\npcchucnang\\congbinhtu.lua")
congbinhtu()
end

function congbinhtu()
   Talk(1, "", "L�i ��i t�m th�i ch�a m�.") 
end

function no()
end