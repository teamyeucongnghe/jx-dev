-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
-- npc Su gia lien dau
function main(NpcIndex)
	Say2("Ch�c n�ng t�m th�i ch�a m�.",1,1,"",
		"��ng/no")
end

function no()
end
