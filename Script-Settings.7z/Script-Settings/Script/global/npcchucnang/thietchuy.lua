-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

function main(NpcIndex)

end

function no()
end
