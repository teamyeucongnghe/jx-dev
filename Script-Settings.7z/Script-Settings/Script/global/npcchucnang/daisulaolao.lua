-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
NEED_ROOM_EMPTY = "Qu� kh�ch h�y s�p x�p l�i h�nh trang."
NOT_TRADE = "��ng/no";
function main()
	Say2("<color=red>��i S� L�o L�o :<color> L�u l�m m�i c� ng��i nh� ta l�m b�nh <enter><enter>Socola Lo�i 2 + Socola Lo�i 1 = <color=green>Socola Lo�i 3<color><enter><enter>Socola Lo�i 3 + Socola Lo�i 2= <color=green>Socola ��c Bi�t<color><enter><enter>Socola ��c Bi�t + Socola Lo�i 3= <color=green>Socola Th��ng H�n<color>",11,5,"",
        "Nh� L�o l�m gi�p lo�i 3/epsocola",
        "Nh� L�o l�m gi�p lo�i ��c Bi�t/epsocola",
        "Nh� L�o l�m gi�p lo�i Th��ng H�n/epsocola",
	"K�t th�c ��i tho�i/no")

function epsocola(sel)
	local socola1 = 	GetItemCount(135,5)
	local socola2 = 	GetItemCount(136,5)
	local socola3 =	        GetItemCount(137,5)
	local socola4 = 	GetItemCount(138,5)
	local socola5 = 	GetItemCount(139,5)
        local succ = 0;
	n = sel + 1
	if(n == 1) then
   	    if(socola1 >= 1 and socola2 >=1 ) then
		   succ = 1;
		   Input("socola3")
		   Msg2Player(EPSOCOLA)
	    end
	    if(succ == 0) then
		   Talk(1,"","Ng��i kh�ng c� mang theo <color=green>Socola Lo�i 2<color> Ho�c<color=green> Socola Lo�i 1 <color>r�i.")
	    end
	elseif(n == 2) then
	    if(socola2 >= 1 and socola3 >=1 ) then
		   succ = 1;
		   Input("socola4")
		   Msg2Player(EPSOCOLA)
	    end
	    if(succ == 0) then
		   Talk(1,"","Ng��i kh�ng c� mang theo<color=green>Socola Lo�i 3 <color>Ho�c<color=green> Socola Lo�i 2<color> r�i.")
	    end	
        elseif(n == 3) then
	    if(socola3 >= 1 and socola4 >=1 ) then
		   succ = 1;
		   Input("socola5")
		   Msg2Player(EPSOCOLA)
	    end
	    if(succ == 0) then
		   Talk(1,"","Ng��i kh�ng c� mang theo<color=green> Socola Lo�i 4 <color>Ho�c<color=green> Socola Lo�i 3<color> r�i.")
            end   
        end
    end
end

function socola3(num)
	local socola1   = 	GetItemCount(135,5)
	local socola2   = 	GetItemCount(136,5)
	local socola3       = 	137
	if(num < 1 or num > 250) then
        Talk(1,"","S� L��ng T�i �a l� <color=green>250 c�i")
        return end
	if(socola1 >= num and socola2 >= num ) then
          AddItem(0,5,socola3,0,0,5,num,0)
               DelItem(135,5,num)
               DelItem(136,5,num)
		Talk(1,"","Ch�c M�ng �� Nh�n ���c<color=green> "..(num).." <color>Socola Lo�i 3.")
        else
 		Talk(1,"","Ng��i Thi�u <color=green>"..(num-socola1).." Socola Lo�i 1<color> ho�c <color=green>"..(num-socola2).." Socola Lo�i 2 <color>r�i.")
        end
end

function socola4(num)
	local socola2   = 	GetItemCount(136,5)
	local socola3   = 	GetItemCount(137,5)
	local socola4       = 	138
	if(num < 1 or num > 250) then
        Talk(1,"","S� L��ng T�i �a l� <color=green>250 c�i")
        return end
	if(socola2 >= num and socola3 >= num ) then
          AddItem(0,5,socola4,0,0,5,num,0)
               DelItem(136,5,num)
               DelItem(137,5,num)
		Talk(1,"","Ch�c M�ng �� Nh�n ���c<color=green> "..(num).." <color>Socola Lo�i ��c Bi�t.")
        else
 		Talk(1,"","Ng��i Thi�u <color=green>"..(num-socola2).." Socola Lo�i 2<color> ho�c <color=green>"..(num-socola3).." Socola Lo�i 3 <color>r�i.")
        end
end

function socola5(num)
	local socola3   = 	GetItemCount(137,5)
	local socola4   = 	GetItemCount(138,5)
	local socola5       = 	139
	if(num < 1 or num > 250) then
        Talk(1,"","S� L��ng T�i �a l� <color=green>250 c�i")
        return end
	if(socola3 >= num and socola4 >= num ) then
          AddItem(0,5,socola5,0,0,5,num,0)
               DelItem(137,5,num)
               DelItem(138,5,num)
		Talk(1,"","Ch�c M�ng �� Nh�n ���c<color=green> "..(num).." <color>Socola Lo�i Th��ng H�n.")
        else
 		Talk(1,"","Ng��i Thi�u <color=green>"..(num-socola3).." Socola Lo�i 3<color> ho�c <color=green>"..(num-socola4).." Socola Lo�i ��c Bi�t <color>r�i.")
        end
end


function noinput()
	FreezeItem(GetTaskTemp(ITEMINDEX),0)
end;


function no()
end
