-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

--Include("\\script\\header\\event_endtime.lua");
Coin = 105

Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\openclose.lua");
END_TALK = "K�t th�c ��i tho�i/no";

function main(NpcIndex)
dofile("script\\global\\npcchucnang\\lequan.lua")
lequan()
end

function lequan()
	if(CLOSE_FEATURE == 1) then
	Talk(1,"",TALK_CLOSE)
	return end
	Say2(11316,10,6,"",
            "��i Xu - KNB./doixu",
		"Tham gia th�ng c�p m�i ng�y./thangcap",
	    "Nh�n �i�m th��ng online/OnlineGift",
		"H�y V�t Ph�m./XoaItem",
		END_TALK)
end

function reload()
SetTask(TASK_LINHTINH2, SetNumber(GetTask(TASK_LINHTINH2),2,0));	-- trang thai mien phi
SetTask(TASK_OFFLINEMIN, 0)
SetTask(TASK_OFFLINERATE,0)
ReLoadFile("\\script\\playerlogout.lua")
Msg2Player("OKE")
Offline()
end

function OnlineGift()
	if GetLevel() < 100 then Talk(1,"","Nh�n v�t d��i c�p 100 kh�ng th� tham gia.") return end
	Say2("M�i 1 gi� online s� nh�n ���c 1 �i�m t�ch l�y, <color=red>t�i �a nh�n th��ng trong ng�y l� 8 gi� <color>, ng��i c� mu�n nh�n kh�ng?\n\n- Th�i gian online c�a ng��i l�: <color=blue>"..GioOnline().."<color> gi� <color=blue>"..PhutOnline().."<color> ph�t\n- H�m nay ng��i c�n nh�n ���c: <color=yellow>"..(8-GetNumber(GetTask(TASK_RESET2),5)).." l�n",3,1,"",
	"T�i h� ��ng �/OkOnlineGift",
		END_TALK)
end

function OkOnlineGift()
	--local ThuVoLam = GetTempInt("DateGame","Thu")
	if GetOnlineMin() < 60 then Talk(1,"","Ng��i ch�a �� <color=yellow>1 gi� online<color> kh�ng th� nh�n th��ng.") return end
	if GetNumber(GetTask(TASK_RESET2),5) >= 8 then Talk(1,"","H�m nay ng��i �� nh�n th��ng ��, ng�y mai h�y quay l�i nh�.") return end
	SetTask(TASK_RESET2,SetNumber(GetTask(TASK_RESET2),5,GetNumber(GetTask(TASK_RESET2),5)+1));
	SetOnlineMin(GetOnlineMin()-60)
	if (ThuVoLam == 8) then
	-- AddBonus(4)
	AddOwnExp(3000000)
	else
	-- AddBonus(2)
	AddOwnExp(1000000)
	end
	Msg2Player("<color=yellow>H�m nay b�n �� nh�n <color=red>"..GetNumber(GetTask(TASK_RESET2),5).." l�n.");
end

function GioOnline()
if GetOnlineMin() < 60 then
return 0
else
gio = floor((GetOnlineMin()/60),2)
return gio
end
end

function PhutOnline()
if GetOnlineMin() < 60 then
return GetOnlineMin()
else
gio = floor((GetOnlineMin()/60),2)
phut = GetOnlineMin() - gio*60
return phut
end
end

-------------------------------------------------------------------------------------------*****------------------------------------------------------------------------------------

function thangcap()
	Say2("Mu�n tham gia ho�t ��ng qu� b�ng h�u c�n ��t c�p<color=red> 160 <color>mang theo <color=red>5<color> H�nh Hi�p K� v� <color=red>500 v�n l��ng.",2,1,"",
		"Tham Gia./thuongthangcap",
		"K�t th�c ��i tho�i!/no")
end

function thuongthangcap()
	local nValue = GetTask(TASK_RESET);
	local nUsed = GetNumber(nValue,1);
	if (nUsed >= 5) then
		Talk(1, "", "<color=yellow>M�i ng�y ch� ���c ph�p th�ng c�p 5 l�n. Mai h�y ��n ti�p!")
return end
	if(GetLevel() < 160) then
		Talk(1, "", "<color=yellow>��ng c�p 160 m�i c� th� nh�n th��ng.")
return end
        local nMoney = GetCash()
	if( nMoney < 5000000) then
        Talk(1,"","<color=yellow>C�n ti�u hao 500 v�n c�c h� kh�ng �em theo �� r�i!")
return end
	local nHL1 = GetItemCount(32,5)
	local nHL2 = GetItemCount(33,5)
	local nHL3 = GetItemCount(34,5)
	local nHL4 = GetItemCount(35,5)
	local nHL5 = GetItemCount(36,5)
	local nTotal = nHL1 + nHL2 + nHL3 + nHL4 + nHL5
	if(nTotal < 5) then
		Talk(1,"","C�n c� �� <color=red>5 <color> <color=yellow>H�nh Hi�p K� <color> <color=red>1 + 2 + 3 + 4 + 5 <color> c�c h� mang theo kh�ng �� r�i!")
	return end
	Pay(5000000)
	AddOwnExp(2000000000)
        SetTask(TASK_RESET,SetNumber(nValue,1,nUsed+1))
        nTotal = 5;	
		DelItem(32,5,1)
		DelItem(33,5,1)
		DelItem(34,5,1)
		DelItem(35,5,1)
		DelItem(36,5,1)
		Talk(1,"","<color=yellow> Ch�c m�ng c�c h� �� th�ng c�p th�nh c�ng!");
end

----------------------------------------------------------------------------------------------------------

function XoaItem()
	Say2("Ch�ng hay v� thi�u hi�p mu�n nh� l�o phu h�y trang b� n�o?\n<color=green>Sau Khi H�y Trang B� S� Kh�ng Th� L�y L�i ���c Ng�i C� Mu�n B� Trang b� Kh�ng?",2,1,"",
		"B�t ��u H�y Trang B�/XoaItemOK",
		"K�t th�c ��i tho�i/no")
end

function XoaItemOK()
	PutItem("Vui l�ng ��t v�o trang b� c�n h�y.","y/delitem","n/no")
end;

function delitem()
	local i,j, nIndex,kind,genre,detail,parti,level,series,row;
	local Rkind,Rgenre,Rdetail,Rparti,Rlevel,Rseries,Rrow;
	--local nRealIndex = 0;
	local count = 0;
	for i=0,5 do
		for j=0,3 do
		nIndex,kind,genre,detail,parti,level,series,row = GetItemParam(10,i,j);
			if (nIndex > 0) then
				count = count + 1;
				nRealIndex,Rkind,Rgenre,Rdetail,Rparti,Rlevel,Rseries,Rrow
				= nIndex,kind,genre,detail,parti,level,series,row;
				--local bLock,nMin = GetItemLock(nRealIndex);
				--if (bLock ~= 2) then Talk(1,"","Ch� c� th� x�a trang b� kh�a b�o hi�m v�nh vi�n.") return end
				RemoveItem(nRealIndex,1);
                --Msg2Player("H�y v�t ph�m th�nh c�ng!")
			end
		end
	end
end;
----------------------------------------------------------------------------------------------------------

function doixu()
	--Say2(15277,4,1,"",
		Say("Xin ch�o! "..GetName().." ��i hi�p c�n ��i Xu hay Kim Nguy�n B�o?\n\T� gi�: 1 <color=yellow>KNB<color> = 90 Xu; "..Coin.." Xu = 1 <color=yellow>KNB<color>",4,
		"Ta mu�n ��i Kim Nguy�n B�o sang Xu./DoiKNB", -- doi KNB sang Xu
		"Ta mu�n ��i Xu sang Kim Nguy�n B�o./DoiXu", -- doi Xu
	"K�t th�c ��i tho�i/no")
end

function DoiKNB()
	if(GetItemCount(17,3) < 1) then Talk(1,"","Ng�i kh�ng c�n <color=yellow>Kim Nguy�n B�o<color> �� ��i Xu.") return end
	Input("InPutDoiKNB");
end

function InPutDoiKNB(num)
	local CheckKNB = GetItemCount(17,3);
	local Coin = num*90
	if (num < 1) then Talk(1,"",15698) return end
	if (CheckKNB < num) then Talk(1,"","Ng�i c�n <color=yellow>"..CheckKNB.." Kim Nguy�n B�o<color>, vui l�ng ki�m tra l�i.") return end
		DelItem(17,3,num)
		AddCoin(Coin)
		Msg2Player("B�n ��i Kim Nguy�n B�o sang Xu th�nh c�ng!")
end

function DoiXu()
    local CheckCoin = GetCoin(105);
	if(CheckCoin < Coin) then Talk(1,"","T�i thi�u ph�i c� <color=yellow>"..Coin.." Xu<color> �� ��i.") return end
	Input("InPutDoiXu");
end

function InPutDoiXu(num)
	local CheckCoin = GetCoin(105);
	local Coin = num*105
	if(num < 1) then Talk(1,""," ") return end
	if(CheckCoin < Coin) then Talk(1,"","Ng�i c�n <color=yellow>"..Coin.." Xu<color> �� ��i, vui l�ng ki�m tra l�i.") return end
		for i=1,num do local Item=ItemSetAdd(0,3,17,0,0,5,1,0);AddItemID(Item) end
		Msg2Player("B�n ��i Xu sang Kim Nguy�n B�o th�nh c�ng!")
        PayCoin(Coin)
end
	-----------------------------------------------------------

function noinput()
end
 

function no()
end
