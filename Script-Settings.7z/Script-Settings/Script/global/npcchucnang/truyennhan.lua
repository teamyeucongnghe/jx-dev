-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
Include("\\script\\header\\taskid.lua");
END_TALK = "K�t th�c ��i tho�i/no";

function main(NpcIndex)
if DUATOP_ACTIVE == 2 then Talk(1,"","T�nh n�ng b�o tr�.") return end
	local Yr,Mth,Dy,Hr,Mn,Se = GetTime()
	Say(11312,2,
	END_TALK)
end

function no()
end
