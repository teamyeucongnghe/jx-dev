-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
NEED_ROOM_EMPTY = "Qu� kh�ch h�y s�p x�p l�i h�nh trang."
NOT_TRADE = "��ng/no";
function main()
	Say2("<color=red>Ti�u B�o :<color> V� S� Huynh,S� T� c�n g� �� s� gi�p �� t�n t�nh <enter><enter>Socola Lo�i 1 + Socola Lo�i 1 = <color=green>Socola Lo�i 2<color>",11,5,"",
        "Nh� �� l�m gi�p socola lo�i 1/epsocola",
	"K�t th�c ��i tho�i/no")

function epsocola(sel)
	local socola1 = 	GetItemCount(135,5)
	local socola2 = 	GetItemCount(136,5)
        local succ = 0;
	n = sel + 1
	if(n == 1) then
   	    if(socola1 >= 1 and socola1 >=1 ) then
		   succ = 1;
		   Input("socola2")
		   Msg2Player(EPSOCOLA)
	    end
	    if(succ == 0) then
		   Talk(1,"","Huynh,T� kh�ng c� mang theo <color=green>Socola Lo�i 2<color> Ho�c<color=green> Socola Lo�i 1 <color>r�i.") 
            end
        end
    end
end

function socola2(num)
	local socola1   = 	GetItemCount(135,5)
	local socola1   = 	GetItemCount(135,5)
	local socola2       = 	136
	if(num < 1 or num > 500) then
        Talk(1,"","S� L��ng T�i �a l� <color=green>250 c�i")
        return end
	if(socola1 >= num and socola1 >= num ) then
          AddItem(0,5,socola2,0,0,5,num,0)
               DelItem(135,5,num)
               DelItem(135,5,num)
		Talk(1,"","Ch�c M�ng �� Nh�n ���c<color=green> "..(num).." <color>Socola Lo�i 2.")
        else
 		Talk(1,"","Ng��i Thi�u <color=green>"..(num-socola1).." Socola Lo�i 1<color> ho�c kh�ng �em theo <color=green>"..(num-socola1).." Socola Lo�i 1 <color>r�i.")
        end
end

function noinput()
	FreezeItem(GetTaskTemp(ITEMINDEX),0)
end;


function no()
end
