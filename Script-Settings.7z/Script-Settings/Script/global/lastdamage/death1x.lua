-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
Include("\\script\\header\\exp_head.lua")
Include("\\script\\item\\event\\event0031.lua");
Include("\\script\\item\\questkey\\quest0064.lua");
Include("\\script\\item\\tools\\tool0010.lua");
NPCLIFE = 200
NPCEXP = 300
--nguoi choi danh quai' cuoi cung` khi chet
function LastDamage(NpcIndex)
end;

--khi phuc sinh
function Revive(NpcIndex)

	local bBlueBoss = 0;
	if RANDOM(100) < 2 then		--xac suat 2% ra boss xanh
		bBlueBoss = 1;
	end
	if bBlueBoss == 1 then	--thiet lap thuoc tinh cho boss xanh
		SetBoss(NpcIndex,1)
		local nLife = floor(NPCLIFE/4);
		if(nLife <= 0) then
			nLife = 1
		end
		SetNpcLife(NpcIndex, nLife);
		SetNpcExp(NpcIndex, NPCEXP*EXP_RATE*4);--kinh nghiem
		SetNpcHitRecover(NpcIndex,12);
		SetNpcSpeed(NpcIndex, 8);
		SetNpcResist(NpcIndex, 75, 75, 75, 75, 75);
		SetNpcDmgEx(NpcIndex,25,0,0,0,0,1);--sat thuong ngoai cong
	else	--thiet lap sat thuong cho npc thuong`
		SetNpcLife(NpcIndex, NPCLIFE);
		SetBoss(NpcIndex,0)
		SetNpcExp(NpcIndex, NPCEXP*EXP_RATE);--set kinh nghiem lai nhu cu
		SetNpcHitRecover(NpcIndex,6);
	end
end

--Khi chet
function DeathSelf(NpcIndex)
end
