-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

function main(NpcIndex)
	Say(12138,4,
	--"Ta ��n nh�n nhi�m v� 150./nhannv",
    --"��n n�i luy�n k� n�ng ./luyenkinang",
	"T�m hi�u c�ch luy�n k� n�ng 120/timhieu120",
	"��ng/no")
end;

function nhannv()
	if(GetLevel() < 150) then
		Talk(1, "", "<color=green>B�n luy�n ��n c�p 150 h�y quay l�i nh�n.")
	return end
	if(CheckRoom(2,1) == 1) then
		local nid = ItemSetAdd(0,2,95,0,0,5,0);
		LockItem(nid);
		AddItemID(nid);
	else
		Talk(1,"","<color=green>Kh�ng �� ch� ch�ng,xin c�c h� s�p x�p l�i h�nh trang.");
	end
end;

function luyenkinang()
	if(GetLevel() < 80) then
		Talk(1,"","<color=yellow>N�i n�y r�t nguy hi�m.Ng��i luy�n ��n c�p 80 h�y quay l�i.")
	return end
	local nValue = GetNumber(GetTask(TASK_DAOTAYTUY),4);
	if(nValue == 0) then	
	Say("<color=green>Ng��i �� s�n s�ng �i v�o M�t C�nh ch�a ? .",4,
	"��n n�i luy�n k� n�ng 9x ./luyen9x",
	"��n n�i luy�n k� n�ng 12x ./luyen12x",
	"��n n�i luy�n k� n�ng 15x ./luyen15x",
	"Ta kh�ng mu�n ./no")
        end	
end;

function luyen9x()
	local TAB_LUNGTUNG = {
			"<color=yellow>Ng�i y�n ! �ang �i ��n M�t C�c...",
		}
	if GetCash() >= 1 then
		NewWorld(969,1729,3194)
		SetFightState(1); 
		Msg2Player(TAB_LUNGTUNG[1])
		Pay(500000)
	else
		Talk(1,"no","<color=yellow> M�i l�n d�ch chuy�n c�n 50v.C�c h� qu�n mang theo ti�n r�i.")
	end
end

function luyen12x()
	if(GetLevel() < 120) then
		Talk(1, "", "<color=yellow>N�i n�y r�t nguy hi�m.Ng��i luy�n ��n c�p 120 h�y quay l�i.")
	return end
	local nTT1 = GetItemCount(13,3)
	local nTT2 = GetItemCount(14,3)
	local nTT3 = GetItemCount(15,3)
	local nTotal = nTT1 + nTT2 + nTT3
	if(nTotal < 3) then
		Talk(1,"","<color=green>C�n 3 vi�n Th�y Tinh. Ng��i kh�ng mang �� r�i!")
	return end
	local w,x,y = GetWorldPos()
	nTotal = 3;
	if(NewWorld(969,1859,3194) == 1) then
                        SetFightState(1);
		for i=1,3 do
			if(nTotal > 0 and nTT1 > 0) then
			DelItem(13,3)
			nTotal = nTotal - 1
			nTT1 = nTT1 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nTT2 > 0) then
			DelItem(14,3)
			nTotal = nTotal - 1
			nTT2 = nTT2 - 1
			end
		end
		for i=1,3 do
			if(nTotal > 0 and nTT3 > 0) then
			DelItem(15,3)
			nTotal = nTotal - 1
			nTT3 = nTT3 - 1
			end
		end
		local nValue = SetNumber(GetTask(TASK_DAOTAYTUY),7,1);
		nValue = SetNumber2(nValue,3,GetCurRevID());
		nValue = SetNumber3(nValue,1,w);
		SetTask(TASK_DAOTAYTUY, nValue);
		SetRevPos(1,969) --diem phuc sinh tren dao
		Msg2Player("<color=green>Ng�i y�n. Ch�ng ta �i M�t C�c!");
	end
end

function luyen15x()
	if(GetLevel() < 150) then
		Talk(1, "", "<color=yellow>N�i n�y r�t nguy hi�m.Ng��i luy�n ��n c�p 150 h�y quay l�i.")
	return end
	if(GetItemCount(20,3) < 6) then
		Talk(1,"","<color=green>C�n 6 vi�n Tinh H�ng b�o th�ch. Ng��i kh�ng mang �� r�i!")
	return end
	local w,x,y = GetWorldPos()
	if(NewWorld(969,1981,3194) == 1) then
                SetFightState(1);
		DelItem(20,3,6)
		local nValue = SetNumber(GetTask(TASK_DAOTAYTUY),7,2);
		nValue = SetNumber2(nValue,3,GetCurRevID());
		nValue = SetNumber3(nValue,1,w);
		SetTask(TASK_DAOTAYTUY, nValue);
		SetRevPos(1,969) --diem phuc sinh tren dao
		Msg2Player("<color=green>Ng�i y�n. Ch�ng ta �i M�t C�c!");
	end
end

function timhieu120()
	Talk(1,"",10341)
end;

function no()
end;
