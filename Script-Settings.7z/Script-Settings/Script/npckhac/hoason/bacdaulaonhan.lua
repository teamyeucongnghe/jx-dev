-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Include("\\script\\header\\event_endtime.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\openclose.lua");
Include("\\script\\npckhac\\hoason\\kimson.lua");
Include("\\script\\global\\npcchucnang\\phantang.lua");--cong tiem nang
END_TALK = "K�t th�c ��i tho�i/no";

function main(NpcIndex)
	if(CLOSE_FEATURE == 1) then
	Talk(1,"",TALK_CLOSE)
	return end
	Say2(11316,3,1,"",
"Ta Mu�n Chuy�n Sinh/chuyensinhv",
		END_TALK)
end

function chuyensinhv() 
SetGlbMissionV(50,5) 
ktcss=GetTask(300)+1
	Say2(11316,3,1,"",
"Chuy�n Sinh Nh�n V�t/chuyensinh2", 
"Tho�t./Exit") 
end 

function chuyensinh2() 
a = GetTask(TASK_CHUYENSINH)
if (TASK_CHUYENSINH) >= 1 and GetLevel() >= 200 and GetCash() >= 5000000 then 
SetTask(TASK_CHUYENSINH,GetTask(TASK_CHUYENSINH)+1) 
if GetTask(TASK_CHUYENSINH) == a + 1 then 
Pay(5000000) 
SetLevel(10) 
AddMagicPoint(20) 
AddProp(10) 
Msg2Player("B�n �� Chuy�n Sinh Th�nh C�ng") 
KickOutSelf() 
Msg2Player("B�n �� Chuy�n Sinh Th�nh C�ng") 
else 
Msg2Player("B�n Kh�ng �� C�p 200 Ho�c Kh�ng   C� 500 V�n L��ng") 
end 
else 
Msg2Player("B�n Kh�ng �� C�p 200 Ho�c Kh�ng   C� 500 V�n L��ng") 
end 
end  

function no()

end;