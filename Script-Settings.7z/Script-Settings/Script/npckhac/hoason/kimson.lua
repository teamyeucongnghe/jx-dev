-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\time.lua");
Include("\\script\\header\\tongkim.lua");
Include("\\script\\library\\worldlibrary.lua")

function main(NpcIndex)
	Say(12251,5,
--"L�y Nh�c V��ng Ki�m V� Danh V�ng/nvk", -- neu ban muon ho tro Nhac Vuong Kiem
"L�p Bang H�i/lapbang",
"T�m Hi�u./timhieu",
"K�t th�c ��i tho�i/no")
end

function lapbang()
OpenTong()
end

function nvk()
AddQuestKey(1)
AddRepute(500)
end

function timhieu()
	Talk(5,"",12252,12259,12260,12261,12262)
end;

function no()
end;