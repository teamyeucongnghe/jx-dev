-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function OnDeath(nDesNpcIndex)
	SetDeathScript("")
	SetPunish(0)
	SetPKMode(0,0)
	SetLogoutRV(0);
	Revive()
end;
