-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Maps Tay Son Thon.
function addnpctayson()

end

function addtraptayson()
	--AddTrapEx1(175,0,0,12,"\\script\\maps\\tayson\\trap\\cong4h.lua")
	--AddTrapEx2(175,0,0,12,"\\script\\maps\\tayson\\trap\\cong8h.lua")
	--AddTrapEx1(175,0,0,12,"\\script\\maps\\tayson\\trap\\cong10h.lua")
	--AddTrapEx2(175,0,0,12,"\\script\\maps\\tayson\\trap\\cong2h.lua")
end

function addobjtayson()

end
