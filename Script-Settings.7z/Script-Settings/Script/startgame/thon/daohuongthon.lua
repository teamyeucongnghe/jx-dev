-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Dao Huong Thieu Trap.

function addnpcdaohuong()
	local nNpcIdx;

	----NPC Mon Phai trong thon-----
	--AddNpcNew(189,1,101,1592*32,3129*32,"\\script\\npcthon\\npcmonphai\\thieulam.lua",6,183)
	--AddNpcNew(184,1,101,1610*32,3196*32,"\\script\\npcthon\\npcmonphai\\thienvuong.lua",6,247)
	--AddNpcNew(186,1,101,1621*32,3205*32,"\\script\\npcthon\\npcmonphai\\ngudoc.lua",6,178)
    --AddNpcNew(177,1,101,1613*32,3174*32,"\\script\\npcthon\\npcmonphai\\duongmon.lua",6,246)
	--AddNpcNew(83 ,1,101,1636*32,3184*32,"\\script\\npcthon\\npcmonphai\\ngami.lua",6,248)
	--AddNpcNew(171,1,101,1581*32,3203*32,"\\script\\npcthon\\npcmonphai\\thuyyen.lua",6,177)	
	--AddNpcNew(103,1,101,1601*32,3124*32,"\\script\\npcthon\\npcmonphai\\caibang.lua",6,194)
	--AddNpcNew(181,1,101,1619*32,3163*32,"\\script\\npcthon\\npcmonphai\\thiennhan.lua",6,240)	
	--AddNpcNew(188,1,101,1635*32,3189*32,"\\script\\npcthon\\npcmonphai\\vodang.lua",6,249)
	--AddNpcNew(309,1,101,1576*32,3145*32,"\\script\\npcthon\\npcmonphai\\conlon.lua",6,181)

	----NPC Chuc nang-----
	nNpcIdx = AddNpcNew(625,1,101,1688*32,3133*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 19);
	nNpcIdx = AddNpcNew(625,1,101,1582*32,3244*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 19);
	nNpcIdx = AddNpcNew(219,1,101,1636*32,3132*32,"\\script\\global\\npcchucnang\\taphoa.lua",6,84); SetNpcValue(nNpcIdx, 23);
	nNpcIdx = AddNpcNew(198,1,101,1612*32,3134*32,"\\script\\global\\npcchucnang\\thoren.lua",6,55); SetNpcValue(nNpcIdx, 22);
	nNpcIdx = AddNpcNew(203,1,101,1681*32,3197*32,"\\script\\global\\npcchucnang\\hieuthuoc.lua",6,251); SetNpcValue(nNpcIdx, 24);
	AddNpcNew(239,1,101,1620*32,3091*32,"\\script\\global\\npcchucnang\\xaphu.lua",6,42)
	AddNpcNew(108,1,101,1676*32,3145*32,"\\script\\global\\npcchucnang\\datau.lua",6,59)
	AddNpcNew(377,1,101,1672*32,3176*32, "\\script\\global\\npcchucnang\\lequan.lua",6,57) 
	AddNpcNew(663,1,101,1702*32,3149*32,"\\script\\global\\npcchucnang\\longngu.lua",6)--enemy199
	AddNpcNew(373,1,101,1647*32,3158*32,"\\script\\global\\npcchucnang\\cthanhquan.lua",6,186)
	AddNpcNew(311,1,101,1665*32,2959*32,"\\script\\global\\npcchucnang\\vosu.lua",6,201)
	--AddNpcNew(87,1,101,1601*32,3188*32,"\\script\\global\\npcchucnang\\trogiup.lua",6,"T©n Thñ Sø Gi¶ ") --308
end

function addtrapdaohuong()

end

function addobjdaohuong()

end