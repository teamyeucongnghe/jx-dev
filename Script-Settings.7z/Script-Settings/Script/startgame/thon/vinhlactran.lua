-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

function addnpcvinhlac()
	local nNpcIdx;
	--Huu dom, heo trang kim mieu 42,43
	AddNpcAuto(3,216,209,{31,42,43},10,99,210,227,DEATHFILE0X,
		5,nil,1,"555",nil,nil,nil,40,5,10,15,nil,600,nil,nil,DROPFILE0X);
	AddNpcAuto(3,233,180,{31,42,43},10,99,174,227,DEATHFILE0X,
		5,nil,1,"555",nil,nil,nil,40,5,10,15,nil,600,nil,nil,DROPFILE0X);
--them quai tai day	
	
	----NPC Mon Phai trong thon-----
	--AddNpcNew(189,1,99,1592*32,3129*32,"\\script\\npcthon\\npcmonphai\\thieulam.lua",6,183)
	--AddNpcNew(184,1,99,1610*32,3196*32,"\\script\\npcthon\\npcmonphai\\thienvuong.lua",6,247)
	--AddNpcNew(186,1,99,1621*32,3995*32,"\\script\\npcthon\\npcmonphai\\ngudoc.lua",6,178)
	--AddNpcNew(177,1,99,1613*32,399*32,"\\script\\npcthon\\npcmonphai\\duongmon.lua",6,246)
	--AddNpcNew(83 ,1,99,1636*32,3184*32,"\\script\\npcthon\\npcmonphai\\ngami.lua",6,248)
	--AddNpcNew(171,1,99,1581*32,3993*32,"\\script\\npcthon\\npcmonphai\\thuyyen.lua",6,177)	
	--AddNpcNew(103,1,99,1601*32,3124*32,"\\script\\npcthon\\npcmonphai\\caibang.lua",6,194)
	--AddNpcNew(181,1,99,1619*32,3163*32,"\\script\\npcthon\\npcmonphai\\thiennhan.lua",6,240)	
	--AddNpcNew(188,1,99,1635*32,3189*32,"\\script\\npcthon\\npcmonphai\\vodang.lua",6,249)
	--AddNpcNew(309,1,99,1576*32,3145*32,"\\script\\npcthon\\npcmonphai\\conlon.lua",6,181)

	----NPC Chuc nang-----
	nNpcIdx = AddNpcNew(625,1,99,1641*32,3262*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 19);
	nNpcIdx = AddNpcNew(625,1,99,1635*32,3181*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 19);
	nNpcIdx = AddNpcNew(219,1,99,1605*32,3280*32,"\\script\\global\\npcchucnang\\taphoa.lua",6,84); SetNpcValue(nNpcIdx, 23);
	nNpcIdx = AddNpcNew(198,1,99,1669*32,3268*32,"\\script\\global\\npcchucnang\\thoren.lua",6,55); SetNpcValue(nNpcIdx, 22);
	nNpcIdx = AddNpcNew(993,1,99,1599*32,3227*32,"\\script\\global\\npcchucnang\\hieuthuoc.lua",6,251); SetNpcValue(nNpcIdx, 24);
	AddNpcNew(239,1,99,1633*32,3300*32,"\\script\\global\\npcchucnang\\xaphu.lua",6,42)
	AddNpcNew(239,1,99,1606*32,3158*32,"\\script\\global\\npcchucnang\\xaphu.lua",6,42)
	AddNpcNew(108,1,99,1648*32,3990*32,"\\script\\global\\npcchucnang\\datau.lua",6,59)
	AddNpcNew(377,1,99,1618*32,3177*32, "\\script\\global\\npcchucnang\\lequan.lua",6,57) 
	AddNpcNew(663,1,99,1626*32,3194*32,"\\script\\global\\npcchucnang\\longngu.lua",6)--enemy199
	AddNpcNew(373,1,99,1660*32,3284*32,"\\script\\global\\npcchucnang\\cthanhquan.lua",6,186)
	--AddNpcNew(87,1,99,1601*32,3188*32,"\\script\\global\\npcchucnang\\trogiup.lua",6,"T©n Thñ Sø Gi¶ ") --308
end

function addtrapvinhlac()
	AddTrapEx1(99,1695,1705,12,"\\script\\maps\\vinhlac\\trap\\cong4h.lua")
	AddTrapEx2(99,1626,1618,12,"\\script\\maps\\vinhlac\\trap\\cong8h.lua")
	AddTrapEx1(99,1595,1584,12,"\\script\\maps\\vinhlac\\trap\\cong10h.lua")
	AddTrapEx2(99,1703,1712,12,"\\script\\maps\\vinhlac\\trap\\cong2h.lua")
end

function addobjvinhlac()
--khong co
end