-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

function addnpcthachco()
	local nNpcIdx;
	--Huu dom, heo trang kim mieu 42,43
	AddNpcAuto(3,211,190,{31,42,43},10,153,174,182,DEATHFILE0X,
		5,nil,1,"555",nil,nil,nil,40,5,10,15,nil,600,nil,nil,DROPFILE0X);
	AddNpcAuto(3,213,196,{31,42,43},10,153,174,182,DEATHFILE0X,
		5,nil,1,"555",nil,nil,nil,40,5,10,15,nil,600,nil,nil,DROPFILE0X);
	AddNpcAuto(3,226,196,{31,42,43},10,153,174,182,DEATHFILE0X,
		5,nil,1,"555",nil,nil,nil,40,5,10,15,nil,600,nil,nil,DROPFILE0X);


	----NPC Mon Phai trong thon-----
	--AddNpcNew(189,1,153,1592*32,3129*32,"\\script\\npcthon\\npcmonphai\\thieulam.lua",6,183)
	--AddNpcNew(184,1,153,1610*32,3196*32,"\\script\\npcthon\\npcmonphai\\thienvuong.lua",6,247)
	--AddNpcNew(186,1,153,1621*32,3205*32,"\\script\\npcthon\\npcmonphai\\ngudoc.lua",6,178)
	--AddNpcNew(177,1,153,1613*32,3153*32,"\\script\\npcthon\\npcmonphai\\duongmon.lua",6,246)
	--AddNpcNew(83 ,1,153,1636*32,3184*32,"\\script\\npcthon\\npcmonphai\\ngami.lua",6,248)
	--AddNpcNew(171,1,153,1581*32,3203*32,"\\script\\npcthon\\npcmonphai\\thuyyen.lua",6,177)	
	--AddNpcNew(103,1,153,1601*32,3124*32,"\\script\\npcthon\\npcmonphai\\caibang.lua",6,194)
	--AddNpcNew(181,1,153,1619*32,3163*32,"\\script\\npcthon\\npcmonphai\\thiennhan.lua",6,240)	
	--AddNpcNew(188,1,153,1635*32,3189*32,"\\script\\npcthon\\npcmonphai\\vodang.lua",6,249)
	--AddNpcNew(309,1,153,1576*32,3145*32,"\\script\\npcthon\\npcmonphai\\conlon.lua",6,181)

	----NPC Chuc nang-----
	nNpcIdx = AddNpcNew(625,1,153,1665*32,3226*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 19);
	nNpcIdx = AddNpcNew(219,1,153,1635*32,3222*32,"\\script\\global\\npcchucnang\\taphoa.lua",6,84); SetNpcValue(nNpcIdx, 23);
	nNpcIdx = AddNpcNew(203,1,153,1601*32,3208*32,"\\script\\global\\npcchucnang\\hieuthuoc.lua",6,251); SetNpcValue(nNpcIdx, 24);
	AddNpcNew(239,1,153,1629*32,3183*32,"\\script\\global\\npcchucnang\\xaphu.lua",6,42)
	AddNpcNew(239,1,153,1690*32,3248*32,"\\script\\global\\npcchucnang\\xaphu.lua",6,42)
	AddNpcNew(108,1,153,1643*32,3235*32,"\\script\\global\\npcchucnang\\datau.lua",6,59)
	AddNpcNew(377,1,153,1607*32,3229*32, "\\script\\global\\npcchucnang\\lequan.lua",6,57) 
	AddNpcNew(663,1,153,1623*32,3242*32,"\\script\\global\\npcchucnang\\longngu.lua",6)--enemy199
	AddNpcNew(373,1,153,1628*32,3204*32,"\\script\\global\\npcchucnang\\cthanhquan.lua",6,186)
	AddNpcNew(311,1,153,1662*32,3260*32,"\\script\\global\\npcchucnang\\vosu.lua",6,201)
	--AddNpcNew(87,1,153,1601*32,3188*32,"\\script\\global\\npcchucnang\\trogiup.lua",6,"T©n Thñ Sø Gi¶ ") --308
end

function addtrapthachco()
	AddTrapEx1(153,1688,3271,12,"\\script\\maps\\thachco\\trap\\cong4h.lua")
	AddTrapEx2(153,1639,3165,12,"\\script\\maps\\thachco\\trap\\cong2h.lua")
end

function addobjthachco()
--thieu
end