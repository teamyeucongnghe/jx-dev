-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

function addnpcchutien()
	local nNpcIdx;
	--Huu dom, heo trang kim mieu 42,43
	AddNpcAuto(3,217,190,{31,42,43},10,100,174,182,DEATHFILE0X,
		5,nil,1,"555",nil,nil,nil,40,5,10,15,nil,600,nil,nil,DROPFILE0X);
	AddNpcAuto(3,183,215,{31,42,43},10,100,174,191,DEATHFILE0X,
		5,nil,1,"555",nil,nil,nil,40,5,10,15,nil,600,nil,nil,DROPFILE0X);
	AddNpcAuto(3,208,215,{31,42,43},10,100,184,207,DEATHFILE0X,
		5,nil,1,"555",nil,nil,nil,40,5,10,15,nil,600,nil,nil,DROPFILE0X);
	AddNpcAuto(3,227,195,{31,42,43},10,100,210,191,DEATHFILE0X,
		5,nil,1,"555",nil,nil,nil,40,5,10,15,nil,600,nil,nil,DROPFILE0X);
	AddNpcAuto(3,227,215,{31,42,43},10,100,210,201,DEATHFILE0X,
		5,nil,1,"555",nil,nil,nil,40,5,10,15,nil,600,nil,nil,DROPFILE0X);
--luyen kc
local MOCNHAN = {
{100414,96334},
{100365,95976},
{1001000,95766},
{100729,95776},
{100942,95944},
{54108,96264},
{54134,96760},
{54078,97000},
{100456,96826},
{100407,96668}
};
local COCGO = {
{52877,94864},
{100028,94930},
{100169,95064},
{100323,910030},
{100735,910010},
{100866,95248},
{100997,95276},
{54103,95568},
{54089,95832}
};
local BAOCAT = {
{100254,95944},
{100241,95686},
{100129,95420},
{100003,95236},
{52765,95124},
{52497,95196},
{521009,95642},
{521003,95944},
{52647,96268},
{100139,96290}
};
	for i=1,getn(MOCNHAN) do
	nNpcIdx = AddNpcNew(414,1,100,MOCNHAN[i][1],MOCNHAN[i][2],DEATH_COCGO,
		5,nil,1,"555",1,1,nil,nil,1,nil,nil,nil,50,nil,nil,"");
	SetNpcValue(nNpcIdx,3);
	end
	for i=1,getn(COCGO) do
	nNpcIdx = AddNpcNew(413,1,100,COCGO[i][1],COCGO[i][2],DEATH_COCGO,
		5,nil,1,"555",1,1,nil,nil,1,nil,nil,nil,50,nil,nil,"");
	SetNpcValue(nNpcIdx,1);
	end
	for i=1,getn(BAOCAT) do
	nNpcIdx = AddNpcNew(415,1,100,BAOCAT[i][1],BAOCAT[i][2],DEATH_COCGO,
		5,nil,1,"555",1,1,nil,nil,1,nil,nil,nil,50,nil,nil,"");
	SetNpcValue(nNpcIdx,2);
	end

	----NPC Mon Phai trong thon-----
	--AddNpcNew(189,1,100,1592*32,3129*32,"\\script\\npcthon\\npcmonphai\\thieulam.lua",6,183)
	--AddNpcNew(184,1,100,1610*32,3196*32,"\\script\\npcthon\\npcmonphai\\thienvuong.lua",6,247)
	--AddNpcNew(186,1,100,1621*32,3205*32,"\\script\\npcthon\\npcmonphai\\ngudoc.lua",6,178)
	--AddNpcNew(177,1,100,1613*32,3100*32,"\\script\\npcthon\\npcmonphai\\duongmon.lua",6,246)
	--AddNpcNew(83 ,1,100,1636*32,3184*32,"\\script\\npcthon\\npcmonphai\\ngami.lua",6,248)
	--AddNpcNew(171,1,100,1581*32,3203*32,"\\script\\npcthon\\npcmonphai\\thuyyen.lua",6,177)	
	--AddNpcNew(103,1,100,1601*32,3124*32,"\\script\\npcthon\\npcmonphai\\caibang.lua",6,194)
	--AddNpcNew(181,1,100,1619*32,3163*32,"\\script\\npcthon\\npcmonphai\\thiennhan.lua",6,240)	
	--AddNpcNew(188,1,100,1635*32,3189*32,"\\script\\npcthon\\npcmonphai\\vodang.lua",6,249)
	--AddNpcNew(309,1,100,1576*32,3145*32,"\\script\\npcthon\\npcmonphai\\conlon.lua",6,181)
	----NPC Chuc nang-----
	nNpcIdx = AddNpcNew(625,1,100,1704*32,3196*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 19);
	nNpcIdx = AddNpcNew(625,1,100,1637*32,3203*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 19);
	nNpcIdx = AddNpcNew(219,1,100,1642*32,3127*32,"\\script\\global\\npcchucnang\\taphoa.lua",6,84); SetNpcValue(nNpcIdx, 23);
	nNpcIdx = AddNpcNew(198,1,100,1664*32,3152*32,"\\script\\global\\npcchucnang\\thoren.lua",6,55); SetNpcValue(nNpcIdx, 22);
	nNpcIdx = AddNpcNew(203,1,100,1661*32,3122*32,"\\script\\global\\npcchucnang\\hieuthuoc.lua",6,251); SetNpcValue(nNpcIdx, 24);
	AddNpcNew(239,1,100,1680*32,3105*32,"\\script\\global\\npcchucnang\\xaphu.lua",6,42)
	AddNpcNew(239,1,100,1597*32,3183*32,"\\script\\global\\npcchucnang\\xaphu.lua",6,42)
	AddNpcNew(239,1,100,1615*32,3098*32,"\\script\\global\\npcchucnang\\xaphu.lua",6,42)
	AddNpcNew(239,1,100,1724*32,3223*32,"\\script\\global\\npcchucnang\\xaphu.lua",6,42)
	AddNpcNew(108,1,100,1618*32,3196*32,"\\script\\global\\npcchucnang\\datau.lua",6,59)
	AddNpcNew(377,1,100,1620*32,3175*32, "\\script\\global\\npcchucnang\\lequan.lua",6,57) 
	AddNpcNew(663,1,100,1609*32,3162*32,"\\script\\global\\npcchucnang\\longngu.lua",6)--enemy199
	AddNpcNew(373,1,100,1631*32,3219*32,"\\script\\global\\npcchucnang\\cthanhquan.lua",6,186)
	AddNpcNew(311,1,100,1734*32,3093*32,"\\script\\global\\npcchucnang\\vosu.lua",6,201)
	--AddNpcNew(87,1,100,1601*32,3188*32,"\\script\\global\\npcchucnang\\trogiup.lua",6,"T©n Thñ Sø Gi¶ ") --308
end

function addtrapchutien()
	AddTrapEx1(100,1721,3244,12,"\\script\\maps\\chutien\\trap\\cong4h.lua")
	AddTrapEx2(100,1603,3204,12,"\\script\\maps\\chutien\\trap\\cong8h.lua")
	AddTrapEx1(100,1600,3095,12,"\\script\\maps\\chutien\\trap\\cong10h.lua")
	AddTrapEx2(100,1692,3095,12,"\\script\\maps\\chutien\\trap\\cong2h.lua")
end

function addobjchutien()
--thieu obj
end