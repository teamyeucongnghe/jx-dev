-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
 
function release_congthanh()

	local nNpcIdx;
	
	----NPC Chuc nang phe Cong-----
	nNpcIdx = AddNpcNew(625,1,325,1561*32,3194*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 1);
	nNpcIdx = AddNpcNew(235,11,221,1894*32,3603*32,"\\script\\feature\\congthanh\\xaphuct.lua",6,42);SetNpcValue(nNpcIdx, 1);
	nNpcIdx = AddNpcNew(203,1,221,1925*32,3576*32,"\\script\\feature\\congthanh\\quanduoc.lua",6,614); SetNpcValue(nNpcIdx, 96);
	nNpcIdx = AddNpcNew(203,1,221,1916*32,3567*32,"\\script\\feature\\congthanh\\quanduoc.lua",6,614); SetNpcValue(nNpcIdx, 96);	
	nNpcIdx = AddNpcNew(55,1,221,1876*32,3566*32,"\\script\\feature\\congthanh\\dacthamcong.lua",6,"C�ng Th�nh Ti�n Qu�n ��c Th�m");SetNpcValue(nNpcIdx, 1);
	nNpcIdx = AddNpcNew(625,1,380,39541,113302,"\\script\\global\\npcchucnang\\ruongchua.lua",6);

	----NPC Chuc nang phe Thu-----
	nNpcIdx = AddNpcNew(625,1,325,1593*32,3094*32,"\\script\\global\\npcchucnang\\ruongchua.lua",6); SetNpcValue(nNpcIdx, 2);
	nNpcIdx = AddNpcNew(235,1,221,1537*32,3204*32,"\\script\\feature\\congthanh\\xaphuct.lua",6,823);
	nNpcIdx = AddNpcNew(203,1,221,1557*32,3225*32,"\\script\\feature\\congthanh\\quanduoc.lua",6,613); SetNpcValue(nNpcIdx, 96);
	nNpcIdx = AddNpcNew(203,1,221,1547*32,3214*32,"\\script\\feature\\congthanh\\quanduoc.lua",6,614); SetNpcValue(nNpcIdx, 96);
	nNpcIdx = AddNpcNew(49,1,221,1566*32,3235*32,"\\script\\feature\\congthanh\\dacthamthu.lua",6,"Th� Th�nh Ti�n Qu�n ��c Th�m");
	nNpcIdx = AddNpcNew(625,1,380,54501,97854,"\\script\\global\\npcchucnang\\ruongchua.lua",6);

    nValue = AddNpcNew(531,1,221,52981,107097,"\\script\\feature\\congthanh\\death_longtru.lua",1,"-Long Tr� ");   

    nValue = AddNpcNew(531,1,221,50924,109171,"\\script\\feature\\congthanh\\death_longtru.lua",1,"-Long Tr� ");   

    nValue = AddNpcNew(531,1,221,55133,104915,"\\script\\feature\\congthanh\\death_longtru.lua",1,"-Long Tr� ");   

    nValue = AddNpcNew(533,1,221,55318,109078,"\\script\\feature\\congthanh\\death_cua.lua",1,"L�p D��ng th�nh m�n",nil);

	nValue = AddNpcNew(533,1,221,53212,111146,"\\script\\feature\\congthanh\\death_cua.lua",1,"L�p D��ng th�nh m�n",nil);

    nValue = AddNpcNew(533,1,221,57474,106954,"\\script\\feature\\congthanh\\death_cua.lua",1,"L�p D��ng th�nh m�n",nil);

end;

function trapcongthanh()

	AddTrapEx1(221,1583,3220,12,"\\script\\maps\\congthanh\\trap\\cong10h.lua")
	AddTrapEx1(221,1590,3264,18,"\\script\\maps\\congthanh\\trap\\cong10h1.lua")
	AddTrapEx1(221,1575,3279,18,"\\script\\maps\\congthanh\\trap\\cong10h2.lua")
	AddTrapEx1(221,1538,3274,18,"\\script\\maps\\congthanh\\trap\\cong10h3.lua")

	AddTrapEx1(221,1905,3549,16,"\\script\\maps\\congthanh\\trap\\cong4h.lua")
	AddTrapEx1(221,1863,3534,18,"\\script\\maps\\congthanh\\trap\\cong4h1.lua")
	AddTrapEx1(221,1849,3549,18,"\\script\\maps\\congthanh\\trap\\cong4h2.lua")
	AddTrapEx1(221,1861,3594,16,"\\script\\maps\\congthanh\\trap\\cong4h3.lua")
end;
