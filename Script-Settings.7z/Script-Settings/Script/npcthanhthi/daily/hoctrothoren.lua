--Phuc Nguyen--
function main(sel)
	Talk(3,"",13904,13905,13906);
end