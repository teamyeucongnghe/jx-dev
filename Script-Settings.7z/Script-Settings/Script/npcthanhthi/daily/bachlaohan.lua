--Phuc Nguyen--
function main(sel)
	Talk(4,"",13732,13733,13734,13735);
end