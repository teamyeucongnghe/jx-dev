--Phuc Nguyen--
function main(sel)
	Talk(2,"",13816,13817);
end