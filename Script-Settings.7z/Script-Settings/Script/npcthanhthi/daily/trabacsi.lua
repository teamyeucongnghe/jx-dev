--Phuc Nguyen--
function main(sel)
	Talk(3,"",13864,13865,13866);
end