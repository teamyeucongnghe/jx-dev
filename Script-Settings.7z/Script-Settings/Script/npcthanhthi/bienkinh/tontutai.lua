-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function main(sel)
	Talk(1,"",random(14669,14672));
end