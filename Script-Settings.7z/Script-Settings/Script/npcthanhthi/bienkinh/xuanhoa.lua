-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function main(sel)
	Talk(1,"",GetSex() == 0 and 14650 or 14651);
end