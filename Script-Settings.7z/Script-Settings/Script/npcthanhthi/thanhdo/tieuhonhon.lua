-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function main(sel)
	if(random(2)==1) then
		Talk(1,"",12460);
	else
		Talk(3,"",12457,12458,12459);
	end
end