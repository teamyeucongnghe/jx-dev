-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function main(sel)
	Say(15197,0);
end