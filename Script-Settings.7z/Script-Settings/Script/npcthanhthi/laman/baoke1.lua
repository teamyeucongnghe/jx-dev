-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
-- You are free to redistribute it under certain conditions.function main(sel)
function main(sel)
	Talk(1,"",10811);
end