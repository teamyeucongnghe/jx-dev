-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function main(sel)
	Talk(4,"",10709,10710,10711,10712);
end