-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function main(sel)
	Talk(4,"",12207,12208,12209,12210);
end