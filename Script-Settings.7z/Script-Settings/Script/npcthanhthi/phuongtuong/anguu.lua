-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function main(sel)
	--12173,12176
	Talk(1,"",12206);
end