-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function main()
	Talk(1,"",random(12218,12220));
end
