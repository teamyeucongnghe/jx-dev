-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
Include("\\script\\header\\taskid.lua");
--Chia lay so du: (a/b - floor(a/b))*b

function main()
	Yr,Mth,Dy,Hr,Mn,Se = GetTime();
	local nNam = GetTask(TASK_NAM) + 2000;
	local nThang = GetTask(TASK_THANG)
	local nNgay = GetTask(TASK_NGAY)
	if(nNam ~= Yr or nThang ~= Mth or nNgay ~= Dy) then --reset 1 ngay moi
		SetTask(TASK_NAM,Yr-2000);
		SetTask(TASK_THANG,Mth);
		SetTask(TASK_NGAY,Dy);
		--reset task can thiet tai day
		SetTask(TASK_RESET,0);
		SetTask(TASK_RESET2,0);
		SetTask(TASK_DATCUOC4, 0);
		SetTask(TASK_DATCUOC5, 0);
		SetTask(TASK_DATCUOC6, 0);
	end
	local nAuraT = GetTask(TASK_THOIGIAN4);
	if(nAuraT > 0) then
		local nCurTime = GetTimeMin();
		if(nCurTime - nAuraT > 0) then
		SetTask(TASK_THOIGIAN4, 0);
		SetRankEx(0,1);
		end
	end
	local nTTLTime = GetTask(TASK_TIENTHAOLO)
	if(nTTLTime > 0) then
		AddSkillState(440, 1, nTTLTime);
	end
	nTTLTime = GetTask(TASK_THIENSONBAOLO)
	if(nTTLTime > 0) then
		AddSkillState(441, 1, nTTLTime*1080);
	end
	nTTLTime = GetTask(TASK_QUEHOATUU)
	if(nTTLTime > 0) then
		AddSkillState(450, 1, nTTLTime*1080);
	end
	DelMagic(1486);

        Msg2Player("<color=yellow>Save r��ng th�nh th� AutoIngame, ho�t ��ng chu�n nh�t!<color>")
        Msg2Player("<color=yellow>Nghi�m c�m h�nh vi gian l�n �i�m trong T�ng Kim, vi ph�m s� b� x� l� nghi�m.")
        Msg2Player("<color=yellow>�� tr�nh b� lo�ng, spam k�nh th�nh th� ngo�i vi�c mua b�n s� b� kh�a chat t�m th�i. Ti�p t�c t�i ph�m s� b� kh�a chat 1 ng�y.")
        Msg2Player("<color=yellow>Nghi�m c�m d�ng autospam �� l�ng m�, x�c ph�m ng��i ch�i kh�c ho�c BQT. Vi ph�m s� b� c�m chat, t�i ph�m s� b� kh�a t�i kho�n.")

------------------kiem tra cac ho tro nhan vat------------------

	CheckAdmin() 
	
	--CheckTuiMau()
	
	--CheckCamNang()
    
	CheckPK() 
	
	--CheckHoTroTanThu()
	
	if(GetLevel() < 10) then 	
	Msg2SubWorld("<color=yellow>Ch�o m�ng <color=red>"..GetName().."<color> tham gia v�o th� gi�i V� L�m Truy�n K�!� .<color>") end
	end

------------------######------------------

function CheckPK()
	local nW, nX, nY = GetWorldPos()
	if (nW == 197) and (GetPK() >= 1) then
		SetTimer(1800*18,6)
		Msg2Player("<color=pink>Tay ng��i �� nhu�m m�u qu� nhi�u, h�y ti�p t�c s�m h�i � thi�n lao.")
		return
	end
	if GetPK() >= 5 and GetPK() < 8 then
		Talk(1,"","<color=pink>Tay ng��i �� nhu�m m�u qu� nhi�u, h�y ti�p t�c s�m h�i � thi�n lao.")
		return
	elseif (GetPK() >= 8) then
		if(NewWorld(197,1590,3206) == 1) then
		LeaveTeam();
		SetPKMode(0,0);--phuc hoi pk tu do
		SetFightState(0);--phi chien dau
		SetPunish(0);
		SetCurCamp(GetCamp());
		SetTimer(1800*18,6)
		Msg2Player("<color=pink>Tay ng��i �� nhu�m m�u qu� nhi�u, h�y ti�p t�c s�m h�i � thi�n lao.")
		end
	end
end

------------------######------------------

function CheckAdmin()
if(GetAccount() ~= "admin" and GetAccount() ~= "vinagame") then return end
	 if GetTaskTemp(20) == 0 then   
	 --SetCamp(0)
	 --SetCurCamp(0)	 
     if(GetItemCount(64,4) < 1) then 
     LenhBai = ItemSetAdd(0,4,64,0,0,5,0,0); -- Lenh Bai GameMaster
     AddItemID(LenhBai);
end
end
end

------------------######------------------

function CheckTuiMau()
if(GetItemCount(0,5) < 1) then 
     TuiMau = ItemSetAdd(0,5,0,0,0,5,0,0); -- Tui Mau
     AddItemID(TuiMau);
end
end

function CheckCamNang()
if(GetItemCount(31,5) < 1) then 
     LenhBai = ItemSetAdd(0,5,31,0,0,5,0,0); -- Lenh Bai Tan Thu
     AddItemID(LenhBai);
end
end

------------------######------------------

function CheckHoTroTanThu() 
	if(GetLevel() > 29) then 
	return end
    AddSkillState( 451, 1 ,388800);--mat trang vang X 1.5 EXP
	AddMagic(1486,1); -- Skill phuc hoi noi luc ,sinh luc.
end	

------------------######------------------
	
function no()

end
