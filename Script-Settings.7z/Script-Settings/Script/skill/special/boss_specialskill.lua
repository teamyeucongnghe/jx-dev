Include("\\script\\skill\\head.lua")
SKILLS={
	xuantianwuji={	--�����޼�
		dynamicmagicshield_v={{{1,100},{20,2000}},{{1,-1},{20,-1}}},
	},
}