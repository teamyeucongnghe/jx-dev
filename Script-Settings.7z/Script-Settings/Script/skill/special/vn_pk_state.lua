Include("\\script\\skill\\head.lua")
SKILLS=
{
	gongjizhuliwan={ --����������
		castspeed_v={{{1,10},{2,10}},{{1,-1},{2,-1}}},
		castspeed_yan_v={{{1,10},{2,10}},{{1,-1},{2,-1}}},
		addphysicsmagic_v={{{1,1000},{2,1000}},{{1,-1},{2,-1}}},
		addpoisonmagic_v={{{1,200},{2,200}},{{1,-1},{2,-1}}},
		addcoldmagic_v={{{1,1000},{2,1000}},{{1,-1},{2,-1}}},
		addfiremagic_v={{{1,1000},{2,1000}},{{1,-1},{2,-1}}},
		addlightingmagic_v={{{1,1000},{2,1000}},{{1,-1},{2,-1}}},
		},
	yinyanghuoxuedan={ --������Ѫ��
		allres_yan_p={{{1,25},{2,25}},{{1,-1},{2,-1}}},
		},
	longju_guanghuan={ --���Թ⻷
		allres_yan_p={{{1,10},{2,10}},{{1,18},{2,18}}},
		allres_p={{{1,10},{2,10}},{{1,18},{2,18}}}
		}
}