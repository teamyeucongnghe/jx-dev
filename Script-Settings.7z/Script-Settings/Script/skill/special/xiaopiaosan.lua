Include("\\script\\skill\\head.lua")
SKILLS={
	xiaopiaosan={ --��Ʈɢ
		meleedamagereturn_p={{{1,25},{2,25}},{{1,18*180},{2,18*180}}},
		rangedamagereturn_p={{{1,25},{2,25}},{{1,18*180},{2,18*180}}},
	},
}