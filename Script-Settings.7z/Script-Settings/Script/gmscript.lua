-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

Include("\\script\\header\\monphaiheader.lua");
Include("\\script\\global\\npcchucnang\\phantang.lua");
Include("\\script\\header\\skill150.lua");
Include("\\script\\item\\\\tools\\tool0059.lua");
Include("\\script\\startgame\\khoitaoserver.lua");
Include("\\script\\header\\trungsinh.lua");

function system ()
Say("Xin ch�o! <color=wood>"..GetName().."<color>! D�y l� h� th�ng qu�n l� m�y ch� <color=red>V� L�m Thi�n Tuy�t<color>.\nHi�n �ang c�:<color=yellow> [ "..GetPlayerCount().." ] <color>ng��i ch�i �ang Online!\nM�i ��i Hi�p ch�n ch�c n�ng d�nh cho Game Master. ",24,
	"T�m Ng��i Ch�i./opentim",
	"Qu�n l� Member/select_name",
	"N�p Xu Cho T�i Kho�n[Nh�p T�n T�i Kho�n]/select_addknb",	
    "Reload Open BETA/OpenBeTa",	
	"Tho�t/no")
end;
	-----------------------------------------------------------

function select_name()
	Input("SelectName");
end

function SelectName(num,name)
	local w,x,y = 0,0,0;
	local user = "Not online!"
	gmidx=PlayerIndex
	for i=1,1999 do 
	PlayerIndex=i
		if(GetAccount() == name) then
		ObjID=PlayerIndex
		user=GetName()
		account=GetAccount()
		level=GetLevel()
		money=GetCash()
		tong=GetTongName()
		pk=GetPK()
		fight=GetFightState()
		vang=GetTask(104)
		knbgui=GetCoin()
		w,x,y = GetWorldPos();
		end
	end
	PlayerIndex=gmidx
	if(account == nil) then Talk(1,"","Ng��i ch�i n�y kh�ng online!") return end
	if(x == 0) then Talk(1,"","Ng��i ch�i b� l�i, kh�ng t�m th�y th�ng tin!") return end
	SetTaskTemp(DESPLAYERID,ObjID)
Say("Xin ch�o! <color=wood>"..GetName().."<color>! D�y l� h� th�ng qu�n l� m�y ch� <color=red>V� L�m Thi�n Tuy�t<color>.\nHi�n �ang c�:<color=yellow> [ "..GetPlayerCount().." ] <color>ng��i ch�i �ang Online!\nM�i ��i Hi�p ch�n ch�c n�ng d�nh cho Game Master. ",24,
		"��a ng��i n�y v�o ��i lao./tonggiam",
		"Cho ng��i n�y ra kh�i ��i lao./thatu",
		"Kick Ra Ngo�i/KickRa",
		"Ch�n ng��i choi Chat/camchat",
		"M� ch�n Chat/mocamchat",
		"Tho�t/no")
end;

function tonggiam()
	local nIdx = GetTaskTemp(DESPLAYERID);
	PlayerIndex = nIdx;	
	if(NewWorld(197,1590,3206) == 1) then
	LeaveTeam();
	SetPKMode(0,0);--phuc hoi pk tu do
	SetFightState(0);--phi chien dau
	SetPunish(0);
	SetCurCamp(GetCamp());
        Msg2SubWorld("��i hi�p "..GetName().." vi ph�m n�n b� giam v�o d�i lao.")
	end
end;

function thatu()
	local nIdx = GetTaskTemp(DESPLAYERID);
	PlayerIndex = nIdx;	
	if(NewWorld(53,1600,3200) == 1) then
	SetFightState(0);--phi chien dau
	SetTask(TASK_LINHTINH,SetNumber(GetTask(TASK_LINHTINH),2,0));
        Msg2SubWorld("Xin ch�c m�ng ��i hi�p "..GetName().." ���c th� kh�i ��i lao.")
	end
end;

function KickRa()
	local nIdx = GetTaskTemp(DESPLAYERID);
	PlayerIndex = nIdx;	
	KickOutSelf()
end;

function camchat()
	local nIdx = GetTaskTemp(DESPLAYERID);
	PlayerIndex = nIdx;	
	SetChatFlag(1)
	SetTask(TASK_CAMCHAT,GetTimeMin()+1440)
        Msg2SubWorld("��i hi�p "..GetName().." vi ph�m n�n b� c�m Chat.")
end

function mocamchat()
	local nIdx = GetTaskTemp(DESPLAYERID);
	PlayerIndex = nIdx;	
	SetChatFlag(0)
	SetTask(TASK_CAMCHAT,0)
        Msg2SubWorld("��i hi�p "..GetName().." �� c� th� Chat b�nh th��ng.")
end
	-----------------------------------------------------------

function select_addknb()
	Input("SelectAddName");
end

function SelectAddName(num,name)
	local w,x,y = 0,0,0;
	local user = "Not online!"
	gmidx=PlayerIndex
	for i=1,1999 do 
	PlayerIndex=i
		if(GetAccount() == name) then
		ObjID=PlayerIndex
		user=GetName()
		account=GetAccount()
		level=GetLevel()
		pk=GetPK()
		Coin=GetTask(104)
		knbgui=GetCoin()
		knbgui2=GetTask(245)
		w,x,y = GetWorldPos();
		end
	end
	PlayerIndex=gmidx
	if (account == nil) then Talk(1,"","Ng��i ch�i n�y kh�ng online!") return end
	if (x == 0) then Talk(1,"","Ng��i ch�i b� l�i, kh�ng t�m th�y th�ng tin!") return end
	SetTaskTemp(DESPLAYERID,ObjID)
Say("Xin ch�o! <color=wood>"..GetName().."<color>! D�y l� h� th�ng qu�n l� m�y ch� <color=red>V� L�m Thi�n Tuy�t<color>.\nHi�n �ang c�:<color=yellow> [ "..GetPlayerCount().." ] <color>ng��i ch�i �ang Online!\nM�i ��i Hi�p ch�n ch�c n�ng d�nh cho Game Master. ",24,
		"Nh�p s� Xu c�n th�m/NapCoin",
		"Tho�t/no")
end;

function NapCoin()
	Input("ThemCoin")
end
	
function ThemCoin(num)
	local nIdx = GetTaskTemp(DESPLAYERID);
	PlayerIndex = nIdx;	
	AddCoin(num)
	Msg2Player("N�p th� th�nh c�ng: <color=yellow>"..num.." Xu")
end
	-----------------------------------------------------------

function OpenBeTa()
	local Mess = "V� L�m Thi�n Tuy�t ch�nh th�c khai m� m�y ch� Th�i S�n, ch�c c�c b�n ch�i game vui v�."
	Msg2SubWorld("<color=cyan>"..Mess)
	AddCountNews("<color=yellow>"..Mess,3)
	AddCountNews2("<color=blue>"..Mess,3)
	ReLoadFile("\\script\\servertimer.lua")
	ReLoadFile("\\script\\playerlogin.lua")
	ReLoadFile("\\script\\maps\\balang\\trap\\cong2h.lua");
	ReLoadFile("\\script\\maps\\balang\\trap\\cong4h.lua");
	ReLoadFile("\\script\\maps\\balang\\trap\\cong8h.lua");
	ReLoadFile("\\script\\maps\\balang\\trap\\cong10h.lua");
	ReLoadFile("\\script\\maps\\longmon\\trap\\cong2h.lua");
	ReLoadFile("\\script\\maps\\longmon\\trap\\cong4h.lua");
	ReLoadFile("\\script\\maps\\longmon\\trap\\cong8h.lua");
	ReLoadFile("\\script\\maps\\longmon\\trap\\cong10h.lua");
	ReLoadFile("\\script\\maps\\giangtan\\trap\\cong4h.lua");
	ReLoadFile("\\script\\maps\\giangtan\\trap\\cong6h.lua");
	ReLoadFile("\\script\\maps\\giangtan\\trap\\cong7h.lua");
	ReLoadFile("\\script\\maps\\giangtan\\trap\\cong8h.lua");
	ReLoadFile("\\script\\maps\\giangtan\\trap\\cong10h.lua");	
	ReLoadFile("\\script\\item\\tools\\tool0149.lua");
	ReLoadFile("\\script\\item\\tools\\tool0106.lua")		
	ReLoadFile("\\script\\global\\npcchucnang\\xaphu.lua");
	ReLoadFile("\\script\\global\\npcchucnang\\lequan.lua");
end
	-----------------------------------------------------------

function opentim()
	Input("timten")
end;

function timten(num, name)
	local nPlayer = FindPlayer(name);
	if(nPlayer <= 0) then
	Msg2Player("Ng��i mu�n t�m hi�n kh�ng c� tr�n m�ng!")
	return end
	local tempid = PlayerIndex;
	PlayerIndex = nPlayer;
	local w,x,y = GetWorldPos();
	PlayerIndex = tempid;
	Msg2Player(name.." �ang �:<color=yellow> "..GetSubWorldName(w).." <color>t�a �� <color=blue>"..floor(x/256).."/"..floor(y/512))
	Talk(1,"",name.." �ang �:<color=yellow> "..GetSubWorldName(w).." <color>t�a �� <color=blue>"..floor(x/256).."/"..floor(y/512));
end;
	-----------------------------------------------------------

function noinput()

end

function no()

end;
