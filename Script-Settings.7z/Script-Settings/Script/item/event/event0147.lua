-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function useitem(nItemIndex)
	if (CheckRoom(2,1) == 0) then
		Talk(1,"","Xin s�p x�p h�nh trang 2x3 �!")
	return end
	vatpham();
	AddOwnExp(5000000)
	RemoveItem(nItemIndex,1,1)
end;

function vatpham()
	local nRand = RANDOM(700);
	if(nRand == 500) then
		local nIndex = ItemSetAdd(0,5,RANDOM(155,156),0,0,5,0,0)
		AddItemID(nIndex);
	elseif(nRand == 450) then
		local nIndex = ItemSetAdd(0,5,150,0,0,5,0,0)
		AddItemID(nIndex);
	elseif(nRand == 300) then
		local nIndex = ItemSetAdd(0,5,112,0,0,5,0,0)
		AddItemID(nIndex);
	elseif(nRand == 120) then
		local nIndex = ItemSetAdd(0,5,RANDOM(113,117),0,5,0,0,0)
		AddItemID(nIndex);
	end
end
