-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

function useitem(nItemIdx)
	if(CheckRoom(2,1) == 1) then
		local nid = ItemSetAdd(0,5,151,0,0,0,50,0);
		AddItemID(nid);
		local nid = ItemSetAdd(0,5,152,0,0,0,50,0);
		AddItemID(nid);
		local nid = ItemSetAdd(0,5,153,0,0,0,50,0);
		AddItemID(nid);
		local nid = ItemSetAdd(0,5,154,0,0,0,50,0);
		AddItemID(nid);
		RemoveItem(nItemIdx,1);
	else
		Talk(1,"","B�n nh�n ���c 50 c�i <color=green>L� + ��u Xanh + N�p + Th�t Heo");
	end
end;
