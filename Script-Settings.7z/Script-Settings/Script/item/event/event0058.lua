-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
Include("\\script\\header\\trangbi.lua");
Include("\\script\\item\\questkey0064.lua");

function useitem(nItemIndex)
	if (CheckRoom(2,3) == 0) then
		Talk(1,"","Xin s�p x�p h�nh trang 5x8 �!")
	return end
	vatpham();
	RemoveItem(nItemIndex,1,1)
end;

function vatpham()
	Say("M�i c� <color=wood>"..GetName().."<color> ch�n trang b�...",2,
	"Cg�n B� Trang B� V�n L�c ./vanloc",
	"Ta kh�ng th�m cho ng��i lu�n ./no")
end

function no()
end;
