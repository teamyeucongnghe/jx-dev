-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function useitem(nItemIdx)
	if(CheckRoom(2,1) == 1) then
		local nid = ItemSetAdd(0,5,135,0,0,0,250,0);
		AddItemID(nid);
		RemoveItem(nItemIdx,1);
	else
		Talk(1,"","B�n nh�n ���c 250 c�i <color=yellow> s�c�la Lo�i 1");
	end
end;


