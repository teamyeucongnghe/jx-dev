-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

Include("\\script\\header\\exp_don.lua");

function useitem(nItemIndex)
	if (CheckRoom(2,3) == 0) then
		Talk(1,"","Xin s�p x�p h�nh trang 2x3 �!")
	return end
	AddOwnExp(500000)
	RemoveItem(nItemIndex,1,1)
end;
