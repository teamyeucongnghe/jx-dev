-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function useitem(nItemIndex)
	if (CheckRoom(2,3) == 0) then
		Talk(1,"","Xin s�p x�p h�nh trang 2x3 �!")
	return end
        vatpham();
	AddOwnExp(5000000)
        Msg2Player("<color=violet>Nh�n ���c 5.000.000 �i�m kinh nghi�m .") 
	RemoveItem(nItemIndex,1,1)
end;


function vatpham()
	nSel = random(0,30);
	if(nSel < 5) then
		local nIndex = ItemSetAdd(0,3,18,0,0,5,0,0)--tu tinh thach
		AddItemID(nIndex);
	elseif(nSel == 12) then
		AddItem(0,4,RANDOM(3,30),0,0,5,0,0)--bk 9x
		AddItemID(nIndex);
	elseif(nSel == 14) then
		AddItem(0,3,18,0,0,5,0,0)--TTT
		AddItemID(nIndex);
	elseif(nSel == 13) then
		AddItem(0,2,random(13,14),0,0,5,2,0)--ttk,vlmt
		AddItemID(nIndex);
	elseif(nSel == 15) then
		local nIndex = ItemSetAdd(0,5,RANDOM(145,146),0,0,5,0,0)--sao,
		AddItemID(nIndex);
	elseif(nSel == 17) then
		AddItem(0,5,161,0,0,5,0,0)--tinh luyen thach.
		AddItemID(nIndex);
	elseif(nSel == 16) then
		AddItem(0,3,21,0,0,5,0,0)--tien ��ng.
		AddItemID(nIndex);
	elseif(nSel == 18) then
		AddItem(0,5,30,0,0,5,0,0)--hat thien tue.
		AddItemID(nIndex);
	elseif(nSel == 19) then
		AddItem(0,2,3,0,0,5,0,0)--BCH 9x.
		AddItemID(nIndex);
	elseif(nSel == 19) then
		AddItem(0,2,45,0,0,5,0,0)--TTL.
		AddItemID(nIndex);
	elseif(nSel == 29) then
		AddItem(0,2,53,0,0,5,0,0)--BCh 120.
		AddItemID(nIndex);
	elseif(nSel == 30) then
		local nIndex = ItemSetAdd(2,0,RANDOM(2,141),0,0,5,0,0)--HKMP
		AddItemID(nIndex);
	end
end
