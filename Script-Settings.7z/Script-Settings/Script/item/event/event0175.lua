-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function useitem(nItemIndex)
	if (CheckRoom(2,3) == 0) then
		Talk(1,"","Xin s�p x�p h�nh trang 2x3 �!")
	return end
	vatpham();
	AddOwnExp(5000000)
        Msg2Player("<color=green>Nh�n ���c 5.000.000 �i�m kinh nghi�m .") 
	RemoveItem(nItemIndex,1,1)
end;
function vatpham()
	MONEY = 10000
	local nRand = RANDOM(700);
	if(nRand == 399) then
		AddItem(2,0,RANDOM(3466,3475),0,0,5,0,0)--phi phong
	elseif(nRand == 299) then
		AddItem(2,0,RANDOM(3493,3506),0,0,5,0,0)--trang suc
	elseif(nRand == 297) then
		AddItem(0,4,RANDOM(5,10),0,0,5,0,0)--linh tinh
	elseif(nRand < 301) then
		local nIndex = ItemSetAdd(0,5,RANDOM(144,146),0,0,5,0,0)--sao,truyentongphu
		AddItemID(nIndex);
	elseif(nRand == 294) then
		AddItem(0,2,45,0,0,5,0,0)--T�i h�ng trang
	end
end
