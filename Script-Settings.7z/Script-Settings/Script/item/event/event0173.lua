-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function useitem(nItemIndex)
	if (CheckRoom(2,3) == 0) then
		Talk(1,"","Xin s�p x�p h�nh trang 2x3 �!")
	return end
	AddOwnExp(500000)
        Msg2Player("<color=violet>Nh�n ���c 500.000 �i�m kinh nghi�m .") 
	RemoveItem(nItemIndex,1,1)
end;
