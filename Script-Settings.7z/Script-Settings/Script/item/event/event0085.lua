-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function useitem(nItemIndex)
	if (CheckRoom(2,3) == 1) then
		for i=4479,4479 do
		Index = ItemSetAdd(2,0,i,0,0,0,5,0)
		SetItemRich(Index,10000) -- �i�m binh gi�p
		AddItemID(Index) -- Add trang b�
		end
		RemoveItem(nItemIndex,1)
		Msg2Player("<color=green>Nh�n ���c Huynh �� Song H�nh.") 
	else
		Talk(1,"","Vui long s�p x�p h�nh trang 2x3.")
	end
end;
