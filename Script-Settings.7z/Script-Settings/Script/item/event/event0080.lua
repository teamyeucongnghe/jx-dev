-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function useitem(nItemIndex)
	if (CheckRoom(6,9) == 1) then
		for i=3889,3893 do
		Index = ItemSetAdd(2,0,i,0,0,0,5,0)
		SetItemRich(Index,10000) -- �i�m binh gi�p
		AddItemID(Index) -- Add trang b�
		end
		RemoveItem(nItemIndex,1)
		Msg2Player("<color=green>Nh�n ���c 1 b� H�c Th�n.") 
	else
		Talk(1,"","Vui long s�p x�p h�nh trang 6x9.")
	end
end;
