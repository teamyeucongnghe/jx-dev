-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
Include( "\\script\\item\\checkmapid.lua" )
Include("\\script\\library\\worldlibrary.lua");

MS_CALLNPCCOUNT_S = 20
MS_CALLNPCCOUNT_J = 21
MAX_CALLNPCCOUNT = 20

function useitem(nItemIdx)	-- 
	if (GetFightState() == 0) then
		Talk(1,"","<color=violet>Kh�ng th� s� d�ng trong t�nh tr�ng phi chi�n ��u!")
		return
	end;
		if(CheckMap() == 0) then
			return
		end
	if (GetCurCamp() == 1) then
		if (GetMissionV(MS_CALLNPCCOUNT_S) >= MAX_CALLNPCCOUNT) then
			Talk(1,"","<color=violet>Hi�n t�i s� l��ng V� tham gia Chi�n tr��ng �� v��t m�c, kh�ng th� g�i th�m ti�p n�a. ")
			return
		else
			SetMissionV(MS_CALLNPCCOUNT_S, GetMissionV(MS_CALLNPCCOUNT_S) + 1)
		end
	elseif (GetCurCamp() == 2) then
		if (GetMissionV(MS_CALLNPCCOUNT_J) >= MAX_CALLNPCCOUNT) then
			Talk(1,"","Hi�n t�i s� l��ng V� tham gia Chi�n tr��ng �� v��t m�c, kh�ng th� g�i th�m ti�p n�a. ")
			return
		else
			SetMissionV(MS_CALLNPCCOUNT_J, GetMissionV(MS_CALLNPCCOUNT_J) + 1)		
		end
	end
	local W,X,Y = GetWorldPos();
		if( GetCurCamp() == 1) then
			CallSjNpc( 2193, 100, W, floor(X/32), floor(Y/32), "G�i V� Ra N�p V�y");
		elseif( GetCurCamp() == 2) then
			CallSjNpc( 2194, 100, W, floor(X/32), floor(Y/32), "G�i V� Ra N�p V�y");
		end
	RemoveItem(nItemIdx,1,1);
end	

function CallSjNpc(NpcId, NpcLevel, W, X, Y, Name)
	local playername = GetName().." ";
	local nNpcIdx;
	nNpcIdx = AddNpcNew(NpcId,NpcLevel, W,( X -  3 ) * 32, Y * 32,"\\script\\feature\\tongkim\\die_binhsi.lua",
		nil,playername..Name,1,"555",0,3000000,nil,1000,200,150,250,nil,nil,30,nil,nil);
	AddMSNpc(1,nNpcIdx);
	nNpcIdx = AddNpcNew(NpcId,NpcLevel, W,( X +  3 ) * 32, Y * 32,"\\script\\feature\\tongkim\\die_binhsi.lua",
		nil,playername..Name,1,"555",0,3000000,nil,1000,200,150,250,nil,nil,30,nil,nil);
	AddMSNpc(1,nNpcIdx);
end
