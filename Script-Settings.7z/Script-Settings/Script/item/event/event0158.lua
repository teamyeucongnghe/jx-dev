-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function useitem(nItemIndex)
	if (CheckRoom(2,3) == 0) then
		Talk(1,"","Xin s�p x�p h�nh trang 2x3 �!")
	return end
	vatpham();
	AddOwnExp(5000000)
	RemoveItem(nItemIndex,1,1)
end;


function vatpham()
		local nRand = RANDOM(700);
	if(nRand == 399) then
		AddItem(0,4,RANDOM(3,30),0,0,5,0,0)--bk 9x
	elseif(nRand == 299) then
		AddItem(0,4,79,0,0,5,0,0)--T�i h�ng trang
	elseif(nRand == 298) then
		AddItem(0,2,random(13,14),0,0,5,2,0)
	elseif(nRand == 297) then
		AddItem(0,2,45,0,0,5,0,0)--linh tinh
	elseif(nRand == 298) then
		AddItem(0,2,random(13,14),0,0,5,2,0)
	elseif(nRand == 9) then
		local nIndex = ItemSetAdd(0,2,5,0,0,5,0,0)--	
		AddItemID(nIndex);
	elseif(nRand < 200) then
		local nIndex = ItemSetAdd(0,3,18,0,0,5,0,0)-- tu tinh thach
		AddItemID(nIndex);
	elseif(nRand < 310) then
		local nIndex = ItemSetAdd(0,5,RANDOM(144,146),0,0,5,0,0)--sao,truyentongphu
		AddItemID(nIndex);
	end
end
