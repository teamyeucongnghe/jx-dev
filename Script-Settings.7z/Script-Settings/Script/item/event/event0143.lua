-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function useitem(nItemIndex)
	if(GetLevel() < 90) then
		Talk(1, "", "<color=yellow>C�p 90 m�i v�o ���c.Ta t�ch thu Ph� �� ng��i kh�i m�t m�ng oan u�ng.")
	return end
	truyentong();
	RemoveItem(nItemIndex,1,1)
end;

function truyentong()
	local TAB_HOATDONG = {
			"Ng�i y�n ! �ang �i ��n Khu V�c Ho�t ��ng Xu�n...",
		}
	if GetCash() >= 1 then
		NewWorld(585,1596,2779)
		SetFightState(1); 
	        LeaveTeam()	--roi nhom, giai tan nhom
                SetRankEx(361) --phong danh hieu binh si~
	        SetPMParam(1,nPlayerDataIdx,1,1) --set param 1 (dang trong giai doan chien dau)
	        SetPunish(1)	--bat tinh nang chet khong mat' gi` 
	        SetPKMode(1,1)--ep kieu chien dau
		Msg2Player(TAB_HOATDONG[1])
		Pay(1)
	else
		Talk(1,"","<color=yellow>Kh�ng c� 1 xu m� c�ng ��i ng�i xe! Ta gi� l�i Ph� c�a ng��i l�m t�n v�t.")
	end
end
