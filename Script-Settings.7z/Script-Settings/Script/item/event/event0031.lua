-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\testgame.lua");
Include("\\script\\header\\nhanhotro.lua");
Include("\\script\\global\\npcchucnang\\phantang.lua");

function useitem(nItemIdx)
ActiveLBHT()
end

function ActiveLBHT()
dofile("script/item/event/event0031.lua")
ActiveLBHTNEW()
end

function ActiveLBHTNEW()
Say("Ch�o m�ng  <color=wood>"..GetName().."<color> tham gia V� L�m Truy�n K�! l�nh b�i h� tr� T�n Th� s� gi�p ��i Hi�p trong qu� tr�nh b�n t�u giang h�.",24,
        --"Ki�m Tra T�a ��./toado",
	    --"Nh�n trang b� xanh/xanhtest",
        "C�ng �i�m Nhanh./tangdiem",
	    "K�t th�c ��i tho�i./no")
end

function toado()
w,x,y = GetWorldPos()
local a = floor(x/32)
local b = floor(y/32)
local nIdPlay = PlayerIndex
Say2(" "..x.." - "..y.."<color=blue> "..w.." <enter><color=yellow> "..a.." <color=red>"..b.."  ",2,1,"",
	"Tr� V�/toado",
	"K�t Th�c/no")
end

----------------------------------------------------------------------------------------------------------

function tangdiem()
	Say("Ng��i mu�n t�ng �i�m lo�i n�o?",5,
	"S�c M�nh./sucmanh",
	"Th�n Ph�p./thanphap",
	"Sinh Kh�./sinhkhi",
	"N�i C�ng./noicong",
	"K�t th�c ��i tho�i/no")
end

function sucmanh()
local count = 1;
local StrTab = {};

for i=1,getn(TIEMNAMG_ARRAY) do
StrTab[count] = TIEMNAMG_ARRAY[i].." �i�m".. "/selsucmanh";
count = count + 1;
end

if(count == 1) then
return end

StrTab[count] = "Quay l�i/cong";
Say("Ng��i mu�n c�ng th�m s�c m�nh bao nhi�u?",count,StrTab)
end

function selsucmanh(sel)
local nSel = sel +1;
local n = GetRestAP()
if n == 0 then Talk(1,"",ALL_POINT_NO_LONGER); return end
if n < TIEMNAMG_ARRAY[nSel] then
IncPoint(1,n); cong();
return end
IncPoint(1,TIEMNAMG_ARRAY[nSel]); cong();
end

function thanphap()
local count = 1;
local StrTab = {};

for i=1,getn(TIEMNAMG_ARRAY) do
StrTab[count] = TIEMNAMG_ARRAY[i].." �i�m".. "/selthanphap";
count = count + 1;
end

if(count == 1) then
return end

StrTab[count] = "Quay l�i/cong";
Say("Ng��i mu�n c�ng th�m th�n ph�p bao nhi�u?",count,StrTab)
end

function selthanphap(sel)
local nSel = sel +1;
local n = GetRestAP()
if n == 0 then Talk(1,"",ALL_POINT_NO_LONGER); return end
if n < TIEMNAMG_ARRAY[nSel] then
IncPoint(2,n); cong();
return end
IncPoint(2,TIEMNAMG_ARRAY[nSel]); cong();
end

function sinhkhi()
local count = 1;
local StrTab = {};

for i=1,getn(TIEMNAMG_ARRAY) do
StrTab[count] = TIEMNAMG_ARRAY[i].." �i�m".. "/selsinhkhi";
count = count + 1;
end

if(count == 1) then
return end

StrTab[count] = "Quay l�i/cong";
Say("Ng��i mu�n c�ng th�m sinh kh� bao nhi�u?",count,StrTab)
end

function selsinhkhi(sel)
local nSel = sel +1;
local n = GetRestAP()
if n == 0 then Talk(1,"",ALL_POINT_NO_LONGER); return end
if n < TIEMNAMG_ARRAY[nSel] then
IncPoint(3,n); cong();
return end
IncPoint(3,TIEMNAMG_ARRAY[nSel]); cong();
end

function noicong()
local count = 1;
local StrTab = {};

for i=1,getn(TIEMNAMG_ARRAY) do
StrTab[count] = TIEMNAMG_ARRAY[i].." �i�m".. "/selnoicong";
count = count + 1;
end

if(count == 1) then
return end

StrTab[count] = "Quay l�i/cong";
Say("Ng��i mu�n c�ng th�m n�i c�ng bao nhi�u?",count,StrTab)
end

function selnoicong(sel)
local nSel = sel +1;
local n = GetRestAP()
if n == 0 then Talk(1,"",ALL_POINT_NO_LONGER); return end
if n < TIEMNAMG_ARRAY[nSel] then
IncPoint(4,n); cong();
return end
IncPoint(4,TIEMNAMG_ARRAY[nSel]); cong();
end

function no()
end
