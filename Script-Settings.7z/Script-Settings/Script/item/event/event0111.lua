-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

function useitem(nItemIndex)
	local nTHBT = GetItemCount(1417,3)
	if (GetLevel() < 80) then
		Talk(1,"","��ng c�p 80 tr� l�n m�i ���c m� <color=yellow>C�t T��ng B�o H�p.")
	return end
	if(nTHBT < 1) then
		Talk(1,"","C�n <color=green>1 Ch�a Kho� C�t T��ng<color>. Kh�ng c� l�m sao ng��i m� ���c!")
	return end
	vatpham();
        DelItem(1417,3,1)
	AddOwnExp(15000000)
	Earn(100000);
	AddRepute(10);
        RemoveItem(nItemIndex,1,1)
end;

function vatpham()
	local nRand = RANDOM(700);
	if(nRand == 399) then
		AddItem(0,3,RANDOM(1703,1705),0,0,5,0,0)
	elseif(nRand == 299) then
		AddItem(0,5,RANDOM(155,156),0,0,5,0,0)
	elseif(nRand == 199) then
		AddItem(0,5,150,0,0,0,5,0)
	elseif(nRand == 99) then
		AddItem(0,5,112,0,0,5,0,0)
	elseif(nRand == 9) then
		local nIndex = ItemSetAdd(0,5,RANDOM(57,60),0,0,5,0,0)	
		AddItemID(nIndex);
	elseif(nRand < 150) then
		AddItem(0,2,135,0,0,5,5,0)
	elseif(nRand < 200) then
		local nIndex = ItemSetAdd(0,5,RANDOM(65,70),0,0,5,1,0)
		AddItemID(nIndex);
	elseif(nRand < 300) then
		local nIndex = ItemSetAdd(0,5,RANDOM(96,100),0,0,5,1,0)
		AddItemID(nIndex);
	elseif(nRand < 400) then
		AddItem(0,5,random(71,72),0,0,5,1,0)
	elseif(nRand < 450) then
		local nIndex = ItemSetAdd(0,3,random(113 ,117),0,0,0,1,0)
		AddItemID(nIndex);
	end
end
