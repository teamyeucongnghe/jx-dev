-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Phao hoa

function useitem(nItemIndex)
	CastSkill(251,1);
    RemoveItem(nItemIndex,1,1);
end;
