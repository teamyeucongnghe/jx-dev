-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Lenh bai vinh du hoang kim
function useitem()
	AddHonor(500)
end;
