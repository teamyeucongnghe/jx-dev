-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
-- H�p Th�n B�

function useitem(nItemIdx)
	if(CheckRoom(2,1) == 1) then
		local nid = ItemSetAdd(0,4,70,0,0,5,0);
		LockItem(nid);
		AddItemID(nid);
		nid = ItemSetAdd(0,4,71,0,0,5,0);
		LockItem(nid);
		AddItemID(nid);
		RemoveItem(nItemIdx,1);
	else
		Talk(1,"","Kh�ng �� ch� ch�ng,xin c�c h� s�p x�p l�i h�nh trang.");
	end
end;
