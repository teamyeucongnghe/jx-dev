-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--B�ch C�u Ho�n 150.

SKILLEXP_ARRAY=
{
	{"Dai luc kim cang chuong",1055},
	{"Vi da hien xu",1056},
	{"tam gioi quy thien",1057},
	{"Hao hung tram",1058},
	{"Tung hoanh bat hoang",1059},
	{"Ba vuong Tam Kim",1060},
	{"Kiem Hoa Van Tinh",1061},
	{"Bang Vu Lac Tinh",1062},
	{"Bang Tuoc Hoat Ky",1063},
	{"Thuy Anh Man Tu",1065},
	{"Vo Anh xuyen",1069},
	{"Thiet Lien Tu Sat",1070},
	{"Can Khon Nhat Trich",1071},
	{"Hinh Tieu cot lap",1066},
	{"U Hon phe Anh",1067},
	{"Thoi thua Luc Long",1073},
	{"Bong Huynh Luoc dia",1074},
	{"Bang Vu Lac Tinh",1062},
	{"Giang Hai no Lan",1075},
	{"Tat Hoa Lieu Nguyen",1076},
	{"Tao hoa Thai thanh",1073},
	{"Kiem Thuy tinh Ha",1078},
	{"Cuu Thien Cuong phong",1079},
	{"Giang Hai no Lan",1080},
	{"Thien Loi chan Nhac",1081}
};

function useitem(nItemIndex)
	if(luyen150() == 1) then
		RemoveItem(nItemIndex,1)
	end
end;

function luyen150()
	local lv;
	for i=1, getn(SKILLEXP_ARRAY) do
		lv = GetMagicLevel(SKILLEXP_ARRAY[i][2]);
		if(lv > 0) then
			if(lv >= 20) then
			return 2 end
			AddSkillExp(SKILLEXP_ARRAY[i][2],10000000)
		return  1 end
	end
	return 0
end
