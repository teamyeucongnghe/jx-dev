-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Thien son bao lo
function useitem(nItemIdx)
	AddSkillState(441, 1, 64800);
end