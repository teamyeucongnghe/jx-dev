-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Tien thao lo x2 kinh nghiem
function useitem(nItemIdx)
	--if (GetNpcExpRate() <= 100) then
		AddSkillState(440, 1, 64800);
	--else
	--	Say("Xin l�i! T�m th�i kh�ng th� s� d�ng ���c Ti�n Th�o L�. ", 0)
	--end
end