-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Lenh bai vinh du thanh dong
function useitem()
	AddHonor(50)
end;
