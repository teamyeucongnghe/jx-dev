-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Phuc Duyen Tieu
function useitem()
AddBless(10)
end;
