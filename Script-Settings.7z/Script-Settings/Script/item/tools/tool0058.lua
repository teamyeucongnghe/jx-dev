-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Hoa hong

function useitem(nItemIndex)
	for i=284,290 do
	CastSkill(i,1);
	end
    RemoveItem(nItemIndex,1,1);
end;
