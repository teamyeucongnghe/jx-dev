-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Bach qua lo ktc + 15
function useitem(nItemIdx)
	AddSkillState(442, 1, 64800);
end