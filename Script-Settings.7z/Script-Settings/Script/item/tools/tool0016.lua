-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Lenh bai vinh du bach ngan
function useitem()
	AddHonor(100)
end;
