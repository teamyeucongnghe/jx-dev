-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Phuc Duyen Trung
function useitem()
AddBless(20)
end;
