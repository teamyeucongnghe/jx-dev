-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
Include("\\script\\library\\worldlibrary.lua");
Include("\\script\\header\\taskid.lua");
Include("\\script\\header\\khobau.lua");

function useitem(nItemIdx)
dofile("script/item/tools/tool0088.lua")
local nKB = GetNumber(GetTask(TASK_VINHLACTRAN),7)
local m = GetTask(TASK_TOADOX)
local n = GetTask(TASK_TOADOY)
local map = GetTask(TASK_MAP)
if nKB == 1 then-- da nhan nhiem vu
Say(""..checkTD(m,n,map).."",2,
	"��o kho b�u/daokhobau",
	"K�t th�c ��i tho�i/no")
return end
Msg2Player("V�t ph�m s� d�ng t�m kho b�u.")
end

function no()
end

function daokhobau()
local m = GetTask(TASK_TOADOX)
local n = GetTask(TASK_TOADOY)
local map = GetTask(TASK_MAP)
local i = RANDOM(1,3)
if checkTD(m,n,map) == BANDO[1] then
	if CheckRoom(3,3) == 0 then
		Talk(1,"","H�nh trang c�n �� tr�ng 3x3 m�i c� th� nh�n ph�n th��ng")
		return end
		SetTask(TASK_VINHLACTRAN,SetNumber(GetTask(TASK_VINHLACTRAN),7,BAUVAT[i][1]))-- 
		nKB = GetNumber(GetTask(TASK_VINHLACTRAN),7)-- 
			for k = 1,nKB do
			h = RANDOM(nKB,10+nKB+nKB)
			AddItem(ITEM[h][1],ITEM[h][2],ITEM[h][3],ITEM[h][4],ITEM[h][5],ITEM[h][6],ITEM[h][7],ITEM[h][8])
			end
			Msg2Player("T�m ���c<color=green>"..BAUVAT[i][2].." <color> .")
		return end
Msg2Player("��o m�i kh�ng th�y g�.")
end

function checkTD(m,n,map)--- tinh khoang cach den toa do can tim 
w,x,y = GetWorldPos()
local a = floor(x/32/8)
local b = floor(y/32/16)
local a1 = floor(m/32/8)
local b1 = floor(n/32/16)
local nX = m-x
local nY = n-y
local nH = floor(sqrt((a1-a)^2+(b1-b)^2))-- sqrt la can bac 2
if w ~= map then
return BANDO[10]
end
if w == map then
if nH < 1 or( nX == 0 and nY == 0)then
return BANDO[1]
end
if nH>= 1 then
if nX< 0 then 
	if nY< 0 then 
	return ""..BANDO[2].." "..nH.." tr��ng"
	end
	if nY> 0 then 
	return ""..BANDO[3].." "..nH.." tr��ng"
	end
	if nY == 0 then
	return ""..BANDO[4].." "..nH.." tr��ng"
	end
	end
if nX> 0 then 
	if nY< 0 then 
	return ""..BANDO[5].." "..nH.." tr��ng"
	end
	if nY> 0 then 
	return ""..BANDO[6].." "..nH.." tr��ng"
	end
	if nY == 0 then
	return ""..BANDO[7].." "..nH.." tr��ng"
	end
end
if nX== 0 then 
	if nY< 0 then 
	return ""..BANDO[8].." "..nH.." tr��ng"
	end
	if nY> 0 then 
	return ""..BANDO[9].." "..nH.." tr��ng"
	end
	end
end
end
end