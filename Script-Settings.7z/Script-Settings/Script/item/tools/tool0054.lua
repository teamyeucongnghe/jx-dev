-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Include("\\script\\header\\taskid.lua");

function useitem(nItemIndex)
	if (GetLevel() < 80) then
		Msg2Player("��ng c�p 80 tr� l�n m�i c� th� luy�n t�p v�i Thi�t la h�n.")
	return end
    AddOwnExp(5000000)
    RemoveItem(nItemIndex,1)
end;
