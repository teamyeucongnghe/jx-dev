-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Phuc Duyen Dai
function useitem()
AddBless(50)
end;
