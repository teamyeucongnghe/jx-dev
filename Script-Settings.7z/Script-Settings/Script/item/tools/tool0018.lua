-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Lenh bai vinh du han thiet
function useitem()
	AddHonor(10)
end;
