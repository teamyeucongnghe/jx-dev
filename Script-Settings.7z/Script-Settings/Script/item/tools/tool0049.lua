-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
--Tien thao lo x2 kinh nghiem
function useitem(nItemIdx)
		AddSkillState(440, 1, 388800);
end