-- Source Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

Include( "\\script\\item\\checkmapid.lua" )

function useitem(nItemIdx)
	if(GetLevel() < 150) then
		Talk(1, "", "Nh�n v�t ph�i ��t ��ng c�p 150 m�i c� th� tri�u h�i Boss.")
	return end
	if(CheckMapForTP() > 1) then
	Msg2Player("N�i n�y kh�ng th� goi Boss ...")
	return end;
	Msg2Player("<color=yellow>C�c h� �� chi�u h�i th�nh c�ng Boss ��nh Cao...");
	local w,x,y = GetWorldPos();
	local nRand = RANDOM(1873,1873);
	local id = AddNpc(nRand,1,SubWorldID2Idx(w),x,y,0);
        SetRankEx(258)
        SetNpcName(id, "Ki�m Ma")	--��t t�n cho qu�i
	SetNpcScript(id, "\\script\\global\\lastdamage\\death_bossdinhcao.lua");
        SetNpcDropScript(id, "\\script\\global\\droprate\\drop_bossdinhcao.lua");
	SetNpcLifeTime(id,32400);--time boss
	RemoveItem(nItemIdx,1);
	if(nRand == 1873) then
	AddCountNews2("Ch�c m�ng "..GetName().." �� chi�u h�i th�nh c�ng Boss ��nh Cao...",3);
	end
end
