                                --===============LENH BAI BOSS DINH CAO===============--
-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame

Include( "\\script\\item\\checkmapid.lua" )

function useitem(nItemIdx)
	if(GetLevel() < 150) then
		Talk(1, "", "Nh©n vËt ph¶i ®¹t ®¼ng cÊp 150 míi cã thÓ triÖu håi Boss.")
	return end
	if(CheckMapForTP() > 1) then
	Msg2Player("N¬i nµy kh«ng thÓ goi Boss ...")
	return end;
	Msg2Player("C¸c h¹ ®· chiªu håi thµnh c«ng Boss §Ønh Cao...");
	local w,x,y = GetWorldPos();
	local nRand = RANDOM(2133,2133); --2133
	local id = AddNpc(nRand,1,SubWorldID2Idx(w),x,y,0);
        SetRankEx(258)
        SetNpcName(id, "KiÕm Tiªn Lý B¹ch")	--§Æt tªn cho qu¸i
	SetNpcScript(id, "\\script\\global\\lastdamage\\death_bossdinhcao.lua");
        SetNpcDropScript(id, "\\script\\global\\droprate\\drop_bossdinhcao.lua");
	SetNpcLifeTime(id,32400);--time boss
	RemoveItem(nItemIdx,1);
	if(nRand == 2133) then
	AddCountNews2("Chóc mõng "..GetName().." ®· chiªu håi thµnh c«ng Boss §Ønh Cao...",3);
	end
end
