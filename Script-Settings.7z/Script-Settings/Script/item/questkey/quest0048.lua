-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
-- Script thu long ngu~ chanh

function useitem(nItemIdx)
	Say2(10372,1,0,GetName(),"Nh�n h�m th� /no");
	RemoveItem(nItemIdx,1);
end;

function no()
end;