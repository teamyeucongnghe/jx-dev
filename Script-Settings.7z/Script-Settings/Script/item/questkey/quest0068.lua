-- Script Vo Lam Truyen Ky
-- Copyright (C) 2005 VinaGame
function useitem(nItemIndex)
	AddEquipExTime(43200)
        Msg2Player("<color=green> C�c h� �� gia h�n th�nh c�ng 30   ng�y s� d�ng T�i H�nh Trang.")
	RemoveItem(nItemIndex,1)
end;
